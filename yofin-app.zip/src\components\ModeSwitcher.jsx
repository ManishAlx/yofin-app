import React from 'react';
import { motion } from 'framer-motion';
import { UserCheck, Briefcase, Sparkles } from 'lucide-react';

export function ModeSwitcher({ mode, setMode }) {
  return (
    <div className="flex flex-col items-center gap-3 my-6 sm:my-8 px-4">
      {/* Sliding Segmented Pill */}
      <div className="relative inline-flex items-center p-1.5 rounded-full border border-white/[0.08] bg-[#0E1017]/90 backdrop-blur-xl shadow-glass">
        {/* Salaried Button */}
        <button
          onClick={() => setMode('salaried')}
          className={`relative z-10 px-5 sm:px-7 py-2.5 rounded-full flex items-center gap-2.5 text-xs sm:text-sm font-bold transition-colors duration-200 cursor-pointer ${
            mode === 'salaried' ? 'text-[#05140D]' : 'text-slate-400 hover:text-white'
          }`}
        >
          <UserCheck size={16} strokeWidth={2.4} />
          <span>Salaried Individual</span>
          {mode === 'salaried' && (
            <motion.div
              layoutId="mode-pill-highlight"
              transition={{ type: 'spring', stiffness: 500, damping: 35 }}
              className="absolute inset-0 rounded-full bg-gradient-to-r from-[#00F5A0] to-[#00D084] shadow-glow-emerald -z-10"
            />
          )}
        </button>

        {/* Business Button */}
        <button
          onClick={() => setMode('business')}
          className={`relative z-10 px-5 sm:px-7 py-2.5 rounded-full flex items-center gap-2.5 text-xs sm:text-sm font-bold transition-colors duration-200 cursor-pointer ${
            mode === 'business' ? 'text-[#03101C]' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Briefcase size={16} strokeWidth={2.4} />
          <span>Business & Freelancer</span>
          {mode === 'business' && (
            <motion.div
              layoutId="mode-pill-highlight"
              transition={{ type: 'spring', stiffness: 500, damping: 35 }}
              className="absolute inset-0 rounded-full bg-gradient-to-r from-[#00D8F6] to-[#3B82F6] shadow-glow-cyan -z-10"
            />
          )}
        </button>
      </div>

      {/* Mode Tagline */}
      <motion.p
        key={mode}
        initial={{ opacity: 0, y: -4 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-xs text-slate-400 flex items-center gap-1.5 font-medium text-center"
      >
        <Sparkles size={13} className={mode === 'salaried' ? 'text-emerald-400' : 'text-cyan-400'} />
        {mode === 'salaried' 
          ? 'Optimized for salary cycle countdown, fixed EMIs, and daily discretionary burn.' 
          : 'Optimized for client retainers, contractor payouts, software OPEX, and cash runway.'
        }
      </motion.p>
    </div>
  );
}
