import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  BellRing, 
  AlertTriangle, 
  AlertOctagon, 
  CheckCircle2, 
  Edit3
} from 'lucide-react';
import { formatINR } from '../lib/formatters';
import { sounds } from '../lib/soundEffects';

export function BudgetAlerts({ 
  transactions = [], 
  mode = 'salaried',
  onAddToast 
}) {
  const [isEditing, setIsEditing] = useState(false);

  const [budgets, setBudgets] = useState(() => {
    const saved = localStorage.getItem(`yofin_budgets_${mode}`);
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return mode === 'salaried'
      ? {
          'Food & Dining': 8000,
          'Shopping & Gadgets': 10000,
          'Groceries & Daily Needs': 6000,
          'Travel & Commute': 5000,
          'Fitness & Health': 15000
        }
      : {
          'Software / Tools': 15000,
          'Cloud & Hosting': 30000,
          'Contractors & Freelancers': 60000,
          'Workspace / Office': 18000
        };
  });

  // Re-sync budgets when user switches between Salaried & Business mode
  React.useEffect(() => {
    const saved = localStorage.getItem(`yofin_budgets_${mode}`);
    if (saved) {
      try {
        setBudgets(JSON.parse(saved));
        return;
      } catch (e) {}
    }
    setBudgets(
      mode === 'salaried'
        ? {
            'Food & Dining': 8000,
            'Shopping & Gadgets': 10000,
            'Groceries & Daily Needs': 6000,
            'Travel & Commute': 5000,
            'Fitness & Health': 15000
          }
        : {
            'Software / Tools': 15000,
            'Cloud & Hosting': 30000,
            'Contractors & Freelancers': 60000,
            'Workspace / Office': 18000
          }
    );
  }, [mode]);

  const categorySpends = {};
  transactions
    .filter(t => t.type === 'expense')
    .forEach(t => {
      categorySpends[t.category] = (categorySpends[t.category] || 0) + Number(t.amount);
    });

  const alertItems = Object.entries(budgets).map(([category, budgetCap]) => {
    const spent = categorySpends[category] || 0;
    const ratio = budgetCap > 0 ? (spent / budgetCap) : 0;
    const percent = Math.round(ratio * 100);

    let status = 'normal';
    if (percent >= 100) status = 'breached';
    else if (percent >= 75) status = 'warning';

    return {
      category,
      budgetCap,
      spent,
      percent,
      status,
      diff: spent - budgetCap
    };
  });

  const breachedCount = alertItems.filter(i => i.status === 'breached').length;
  const warningCount = alertItems.filter(i => i.status === 'warning').length;

  const handleUpdateBudget = (category, newCap) => {
    const updated = { ...budgets, [category]: Number(newCap) };
    setBudgets(updated);
    localStorage.setItem(`yofin_budgets_${mode}`, JSON.stringify(updated));
  };

  const handleSaveAll = (e) => {
    e.preventDefault();
    localStorage.setItem(`yofin_budgets_${mode}`, JSON.stringify(budgets));
    setIsEditing(false);
    sounds.playSuccess();
    if (onAddToast) onAddToast('Category budget limits saved!', 'success');
  };

  return (
    <motion.div 
      whileHover={{ y: -2 }}
      className={`glass-card p-6 sm:p-7 my-6 transition-all duration-300 ${
        breachedCount > 0 ? 'border-rose-500/40' : warningCount > 0 ? 'border-amber-500/40' : 'border-white/[0.08]'
      }`}
    >
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3 mb-5">
        <div className="flex items-center gap-3.5">
          <div 
            className={`w-11 h-11 rounded-xl flex items-center justify-center border transition-colors ${
              breachedCount > 0 
                ? 'bg-rose-500/15 border-rose-500/40 text-rose-400' 
                : 'bg-emerald-500/15 border-emerald-500/40 text-emerald-400'
            }`}
          >
            <BellRing size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h3 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
                Smart Category Budget Alerts
              </h3>
              {breachedCount > 0 ? (
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider bg-rose-500/15 text-rose-400 border border-rose-500/30">
                  {breachedCount} Breached!
                </span>
              ) : warningCount > 0 ? (
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider bg-amber-500/15 text-amber-400 border border-amber-500/30">
                  {warningCount} Approaching Limit
                </span>
              ) : (
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  All Budgets Safe
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400">
              Live threshold monitoring: triggers amber caution at 75% and red breach alert at 100%
            </p>
          </div>
        </div>

        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsEditing(!isEditing)}
          className="btn-fintech-secondary text-xs !py-1.5 !px-3.5 rounded-full"
        >
          <Edit3 size={13} />
          <span>{isEditing ? 'Close Edit' : 'Edit Budget Caps'}</span>
        </motion.button>
      </div>

      {/* Edit Form Drawer */}
      <AnimatePresence>
        {isEditing && (
          <motion.form
            onSubmit={handleSaveAll}
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="p-5 rounded-2xl bg-black/45 border border-white/[0.08] mb-5"
          >
            <div className="text-sm font-bold text-white mb-3">
              Set Monthly Spending Ceilings (₹)
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {Object.entries(budgets).map(([cat, cap]) => (
                <div key={cat}>
                  <label className="text-xs text-slate-300 block mb-1">
                    {cat}
                  </label>
                  <input
                    type="number"
                    value={cap}
                    onChange={(e) => handleUpdateBudget(cat, e.target.value)}
                    className="fintech-input"
                  />
                </div>
              ))}
            </div>

            <div className="flex justify-end gap-2.5 mt-4">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="btn-fintech-secondary text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn-fintech-primary text-xs"
              >
                Save All Ceilings
              </button>
            </div>
          </motion.form>
        )}
      </AnimatePresence>

      {/* Budget Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {alertItems.map(item => {
          const isBreached = item.status === 'breached';
          const isWarning = item.status === 'warning';

          const cardBorder = isBreached 
            ? 'border-rose-500/40 bg-rose-500/[0.06]' 
            : isWarning 
            ? 'border-amber-500/40 bg-amber-500/[0.05]' 
            : 'border-white/[0.08] bg-black/35';

          const progressColor = isBreached 
            ? 'bg-rose-500' 
            : isWarning 
            ? 'bg-amber-400' 
            : 'bg-emerald-400';

          return (
            <div
              key={item.category}
              className={`p-4 sm:p-5 rounded-2xl border transition-all ${cardBorder} flex flex-col justify-between gap-3`}
            >
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-bold text-white">
                    {item.category}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase ${
                    isBreached ? 'bg-rose-500/15 text-rose-400 border-rose-500/30' : isWarning ? 'bg-amber-500/15 text-amber-400 border-amber-500/30' : 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                  }`}>
                    {item.percent}% USED
                  </span>
                </div>

                <div className="flex items-baseline justify-between mt-2">
                  <span className={`font-mono text-xl font-extrabold ${isBreached ? 'text-rose-400' : 'text-white'}`}>
                    {formatINR(item.spent)}
                  </span>
                  <span className="text-xs text-slate-400">
                    of {formatINR(item.budgetCap)} cap
                  </span>
                </div>

                <div className="h-1.5 bg-white/[0.06] rounded-full overflow-hidden mt-3">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min(100, item.percent)}%` }}
                    transition={{ duration: 0.8 }}
                    className={`h-full rounded-full ${progressColor}`}
                  />
                </div>
              </div>

              <div className={`text-xs flex items-center gap-1.5 font-medium ${
                isBreached ? 'text-rose-400' : isWarning ? 'text-amber-400' : 'text-slate-400'
              }`}>
                {isBreached ? (
                  <>
                    <AlertOctagon size={13} className="shrink-0" />
                    <span>Breached by {formatINR(item.diff)}! Freeze orders.</span>
                  </>
                ) : isWarning ? (
                  <>
                    <AlertTriangle size={13} className="shrink-0" />
                    <span>Only {formatINR(item.budgetCap - item.spent)} remaining.</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 size={13} className="shrink-0 text-emerald-400" />
                    <span>{formatINR(item.budgetCap - item.spent)} buffer available.</span>
                  </>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </motion.div>
  );
}
