import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield } from 'lucide-react';
import { formatINR } from '../lib/formatters';

export function GoalVault({ 
  settings, 
  vaultData, 
  onUpdateVault 
}) {
  const [isEditing, setIsEditing] = useState(false);
  const [fundAmount, setFundAmount] = useState(vaultData?.saved || 65000);
  const [targetAmount, setTargetAmount] = useState(vaultData?.target || 150000);

  const progress = Math.min(100, Math.round((fundAmount / targetAmount) * 100));

  const handleQuickAdd = (delta) => {
    const newVal = Math.max(0, fundAmount + delta);
    setFundAmount(newVal);
    onUpdateVault({ saved: newVal, target: targetAmount });
  };

  const handleSave = (e) => {
    e.preventDefault();
    onUpdateVault({ saved: Number(fundAmount), target: Number(targetAmount) });
    setIsEditing(false);
  };

  return (
    <motion.div 
      whileHover={{ y: -2 }}
      className="glass-card p-6 sm:p-7 my-6"
    >
      <div className="flex items-center justify-between flex-wrap gap-3 mb-5">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-purple-500/15 border border-purple-500/35 text-purple-400 flex items-center justify-center shrink-0">
            <Shield size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h3 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
                Emergency Fund & Goal Vault
              </h3>
              <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider bg-purple-500/15 text-purple-400 border border-purple-500/30">
                {progress}% FUNDED
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Dedicated safety cushion to protect your payday survival from sudden emergencies
            </p>
          </div>
        </div>

        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsEditing(!isEditing)}
          className="btn-fintech-secondary text-xs !py-1.5 !px-3.5 rounded-full"
        >
          {isEditing ? 'Cancel' : 'Edit Target'}
        </motion.button>
      </div>

      {/* Progress Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 mb-4">
        <div className="p-4 rounded-2xl bg-black/40 border border-white/[0.08]">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">SAVED IN VAULT</div>
          <div className="font-mono text-2xl font-extrabold text-purple-400 mt-1">
            {formatINR(fundAmount)}
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-black/40 border border-white/[0.08]">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">TARGET GOAL (3 MO)</div>
          <div className="font-mono text-2xl font-extrabold text-white mt-1">
            {formatINR(targetAmount)}
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-black/40 border border-white/[0.08]">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">REMAINING GAP</div>
          <div className="font-mono text-2xl font-extrabold text-rose-400 mt-1">
            {formatINR(Math.max(0, targetAmount - fundAmount))}
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mb-4">
        <div className="h-2.5 bg-white/[0.06] rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.8 }}
            className="h-full rounded-full bg-gradient-to-r from-purple-500 via-indigo-500 to-emerald-400"
          />
        </div>
      </div>

      {/* Quick Deposit Actions */}
      <div className="flex items-center justify-between flex-wrap gap-2.5 pt-1">
        <div className="flex gap-2">
          <button
            onClick={() => handleQuickAdd(2000)}
            className="btn-fintech-secondary text-xs !py-1 !px-2.5"
          >
            + ₹2,000
          </button>
          <button
            onClick={() => handleQuickAdd(5000)}
            className="btn-fintech-secondary text-xs !py-1 !px-2.5"
          >
            + ₹5,000
          </button>
          <button
            onClick={() => handleQuickAdd(10000)}
            className="btn-fintech-secondary text-xs !py-1 !px-2.5"
          >
            + ₹10,000
          </button>
        </div>

        <div className="text-xs text-slate-400 font-medium">
          {progress >= 100 ? '🎉 Emergency Goal Completed!' : `${100 - progress}% left to complete vault`}
        </div>
      </div>

      {/* Edit Target Form */}
      <AnimatePresence>
        {isEditing && (
          <motion.form
            onSubmit={handleSave}
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-4 p-4 rounded-2xl bg-black/45 border border-white/[0.08]"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-slate-300 block mb-1">
                  Current Saved Funds (₹)
                </label>
                <input
                  type="number"
                  value={fundAmount}
                  onChange={(e) => setFundAmount(Number(e.target.value))}
                  className="fintech-input"
                />
              </div>

              <div>
                <label className="text-xs text-slate-300 block mb-1">
                  Target Vault Goal (₹)
                </label>
                <input
                  type="number"
                  value={targetAmount}
                  onChange={(e) => setTargetAmount(Number(e.target.value))}
                  className="fintech-input"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2.5 mt-3">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="btn-fintech-secondary text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn-fintech-primary text-xs"
              >
                Save Vault
              </button>
            </div>
          </motion.form>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
