import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  X, 
  Plus, 
  ArrowUpRight, 
  ArrowDownRight, 
  FileText, 
  Smartphone
} from 'lucide-react';
import { parseBankSMS } from '../lib/smsParser';

export function TransactionModal({ 
  isOpen, 
  onClose, 
  onAddTransaction, 
  mode 
}) {
  const [activeTab, setActiveTab] = useState('sms'); // 'sms' | 'manual'
  const [smsText, setSmsText] = useState('');
  const [parsedData, setParsedData] = useState(null);

  // Manual Form State
  const [type, setType] = useState('expense');
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState(mode === 'salaried' ? 'Food & Dining' : 'Software / Tools');
  const [tag, setTag] = useState('essential');
  const [paymentMethod, setPaymentMethod] = useState('UPI');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [isRecurring, setIsRecurring] = useState(false);
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const salariedCategories = [
    'Food & Dining',
    'Rent & Maintenance',
    'Groceries & Daily Needs',
    'Shopping & Gadgets',
    'Travel & Commute',
    'Utilities & Wi-Fi',
    'Fitness & Health',
    'Entertainment & OTT',
    'Salary Credit',
    'Side Hustle & Freelance',
    'Investments & SIP'
  ];

  const businessCategories = [
    'Software / Tools',
    'Cloud & Hosting',
    'Workspace / Office',
    'Contractors & Freelancers',
    'Client Retainer',
    'Project Milestone',
    'Marketing & Ads',
    'Legal & Accounting',
    'Hardware / Equipment',
    'Travel & Client Dinners'
  ];

  const categories = mode === 'salaried' ? salariedCategories : businessCategories;

  const handleSmsChange = (text) => {
    setSmsText(text);
    if (text.length > 10) {
      const parsed = parseBankSMS(text, mode);
      setParsedData(parsed);
      if (parsed) {
        setTitle(parsed.title);
        setAmount(parsed.amount);
        setType(parsed.type);
        setCategory(parsed.category);
        setTag(parsed.tag);
        setPaymentMethod(parsed.paymentMethod);
      }
    } else {
      setParsedData(null);
    }
  };

  const handleApplySampleSms = (sample) => {
    handleSmsChange(sample);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title || !amount) return;

    onAddTransaction({
      id: `tx-${Date.now()}`,
      title,
      amount: parseFloat(amount),
      type,
      category,
      tag: mode === 'business' 
        ? (tag === 'wants' ? 'client_payout' : 'business_opex')
        : tag,
      mode,
      payment_method: paymentMethod,
      date,
      is_recurring: isRecurring,
      notes
    });

    setTitle('');
    setAmount('');
    setSmsText('');
    setParsedData(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto" onClick={onClose}>
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.94, y: 16 }}
        transition={{ type: 'spring', stiffness: 450, damping: 30 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg p-6 sm:p-7 rounded-3xl glass-card-elevated border border-white/[0.12] max-h-[90vh] overflow-y-auto relative"
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-extrabold tracking-tight">Log Transaction</h3>
            <p className="text-xs text-slate-400">
              Auto-extract from bank SMS or enter details manually
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/[0.04] border border-white/[0.08] hover:bg-white/[0.08] text-slate-400 hover:text-white flex items-center justify-center transition-all cursor-pointer"
          >
            <X size={16} />
          </button>
        </div>

        {/* Tab Toggle: Smart SMS vs Manual */}
        <div className="grid grid-cols-2 gap-1.5 p-1 rounded-full border border-white/[0.08] bg-black/40 mb-4">
          <button
            type="button"
            onClick={() => setActiveTab('sms')}
            className={`py-2 px-3 rounded-full text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'sms' 
                ? 'bg-gradient-to-r from-emerald-500/20 to-cyan-500/20 text-emerald-300 border border-emerald-500/30' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone size={14} />
            <span>⚡ Paste Bank/UPI SMS</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('manual')}
            className={`py-2 px-3 rounded-full text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'manual' 
                ? 'bg-white/[0.08] text-white border border-white/[0.12]' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileText size={14} />
            <span>Manual Form</span>
          </button>
        </div>

        {/* SMART SMS TAB CONTENT */}
        {activeTab === 'sms' && (
          <div className="mb-4">
            <label className="text-xs text-slate-300 block mb-1.5 font-medium">
              Paste any Indian Bank / UPI / Card SMS (HDFC, SBI, ICICI, Kotak, GPay, Paytm)
            </label>
            <textarea
              rows={3}
              placeholder="e.g. Sent Rs. 420.00 from Kotak Bank to Swiggy on 22-Oct-26 via UPI Ref 4291829..."
              value={smsText}
              onChange={(e) => handleSmsChange(e.target.value)}
              className="fintech-input text-xs resize-none"
            />

            {/* Quick Test Chips */}
            <div className="flex gap-1.5 mt-2 flex-wrap items-center">
              <span className="text-[11px] text-slate-500 font-medium">Try Samples:</span>
              <button
                type="button"
                onClick={() => handleApplySampleSms('Paid Rs. 380 to Swiggy via UPI Ref 428190 on 22-Oct')}
                className="text-[11px] px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 hover:bg-cyan-500/20 cursor-pointer"
              >
                Swiggy ₹380
              </button>
              <button
                type="button"
                onClick={() => handleApplySampleSms('A/C XX1234 Credited for Rs.95,000.00 on 01-Oct by Fintech Corp Salary')}
                className="text-[11px] px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 hover:bg-emerald-500/20 cursor-pointer"
              >
                Salary ₹95k
              </button>
              <button
                type="button"
                onClick={() => handleApplySampleSms('INR 2,450 debited on Credit Card at Blinkit Quick Commerce')}
                className="text-[11px] px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/20 hover:bg-amber-500/20 cursor-pointer"
              >
                Blinkit ₹2,450
              </button>
            </div>

            {/* Live Parser Feedback Box */}
            {parsedData && (
              <motion.div
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-3 p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-between flex-wrap gap-2"
              >
                <div>
                  <div className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider">
                    ⚡ AUTO-PARSED TRANSACTION
                  </div>
                  <div className="text-sm font-bold text-white mt-0.5">
                    {parsedData.title} • ₹{parsedData.amount}
                  </div>
                  <div className="text-xs text-slate-300">
                    {parsedData.category} • {parsedData.paymentMethod} • {parsedData.tag === 'essential' ? 'Essential' : 'Optional Want'}
                  </div>
                </div>

                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Ready to Log
                </span>
              </motion.div>
            )}
          </div>
        )}

        {/* MAIN FORM */}
        <form onSubmit={handleSubmit} className="flex flex-col gap-3.5">
          {/* Type Toggle */}
          <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-black/40 border border-white/[0.08]">
            <button
              type="button"
              onClick={() => setType('expense')}
              className={`py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                type === 'expense' 
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <ArrowDownRight size={14} />
              <span>Expense (Debit)</span>
            </button>

            <button
              type="button"
              onClick={() => setType('income')}
              className={`py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                type === 'income' 
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <ArrowUpRight size={14} />
              <span>Income (Credit)</span>
            </button>
          </div>

          {/* Amount & Title */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs text-slate-300 block mb-1">
                Amount (₹)
              </label>
              <div className="relative">
                <span className={`absolute left-3 top-1/2 -translate-y-1/2 font-bold text-sm ${type === 'expense' ? 'text-rose-400' : 'text-emerald-400'}`}>
                  ₹
                </span>
                <input
                  type="number"
                  step="any"
                  required
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="fintech-input !pl-7 font-mono font-bold text-base"
                />
              </div>
            </div>

            <div className="sm:col-span-2">
              <label className="text-xs text-slate-300 block mb-1">
                Payee / Description
              </label>
              <input
                type="text"
                required
                placeholder={type === 'expense' ? 'e.g. Swiggy, Uber, Rent' : 'e.g. Salary, Client Retainer'}
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="fintech-input"
              />
            </div>
          </div>

          {/* Category & Tag */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-slate-300 block mb-1">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="fintech-input"
              >
                {categories.map(c => (
                  <option key={c} value={c} className="bg-[#121520]">{c}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs text-slate-300 block mb-1">
                Discretionary Tag
              </label>
              <select
                value={tag}
                onChange={(e) => setTag(e.target.value)}
                className="fintech-input"
              >
                <option value="essential" className="bg-[#121520]">
                  {mode === 'salaried' ? '🟢 Essential (Needs/Fixed)' : '🟢 Business OPEX (Core)'}
                </option>
                <option value="wants" className="bg-[#121520]">
                  {mode === 'salaried' ? '🟡 Optional / Wants (Lifestyle)' : '🟣 Contractor / Non-Core'}
                </option>
              </select>
            </div>
          </div>

          {/* Payment Method & Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-slate-300 block mb-1">
                Payment Method
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="fintech-input"
              >
                <option value="UPI" className="bg-[#121520]">UPI (Google Pay / PhonePe)</option>
                <option value="Credit Card" className="bg-[#121520]">Credit Card</option>
                <option value="Bank Transfer" className="bg-[#121520]">Net Banking / IMPS</option>
                <option value="Debit Card" className="bg-[#121520]">Debit Card</option>
                <option value="Cash" className="bg-[#121520]">Cash</option>
              </select>
            </div>

            <div>
              <label className="text-xs text-slate-300 block mb-1">
                Date
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="fintech-input"
              />
            </div>
          </div>

          {/* Submit */}
          <div className="flex justify-end gap-2.5 mt-2 pt-2 border-t border-white/[0.08]">
            <button
              type="button"
              onClick={onClose}
              className="btn-fintech-secondary text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn-fintech-primary text-xs"
            >
              <Plus size={15} />
              <span>Record Transaction</span>
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}
