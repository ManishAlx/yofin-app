import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  CheckCircle2, 
  Plus, 
  Trash2, 
  Receipt, 
  Clock
} from 'lucide-react';
import { formatINR } from '../lib/formatters';

export function InvoiceTracker({ 
  invoices = [], 
  onAddInvoice, 
  onMarkPaid, 
  onDeleteInvoice 
}) {
  const [showAdd, setShowAdd] = useState(false);
  const [client, setClient] = useState('');
  const [amount, setAmount] = useState('');
  const [dueDate, setDueDate] = useState(new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);
  const [isGst, setIsGst] = useState(true);

  const pendingInvoices = invoices.filter(i => i.status === 'pending');
  const paidInvoices = invoices.filter(i => i.status === 'paid');

  const pendingReceivables = pendingInvoices.reduce((sum, i) => sum + Number(i.amount), 0);
  const totalRevenue = paidInvoices.reduce((sum, i) => sum + Number(i.amount), 0);

  const gstReserve = Math.round(totalRevenue * 0.18);
  const incomeTaxReserve = Math.round(totalRevenue * 0.10);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!client || !amount) return;

    onAddInvoice({
      id: `inv-${Date.now()}`,
      client,
      amount: parseFloat(amount),
      dueDate,
      status: 'pending',
      isGst,
      createdAt: new Date().toISOString().split('T')[0]
    });

    setClient('');
    setAmount('');
    setShowAdd(false);
  };

  return (
    <motion.div 
      whileHover={{ y: -2 }}
      className="glass-card p-6 sm:p-7 my-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3 mb-5">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-cyan-500/15 border border-cyan-500/35 text-cyan-400 flex items-center justify-center shrink-0">
            <Receipt size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h3 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
                Client Invoices & Indian Tax Reserve (44ADA / GST)
              </h3>
              <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider bg-cyan-500/15 text-cyan-400 border border-cyan-500/30">
                {pendingInvoices.length} Pending
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Track milestone receivables and calculate Section 44ADA + 18% GST tax reserves
            </p>
          </div>
        </div>

        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowAdd(!showAdd)}
          className="btn-fintech-primary text-xs !py-1.5 !px-3.5 rounded-full"
        >
          <Plus size={14} />
          <span>New Client Invoice</span>
        </motion.button>
      </div>

      {/* Tax Reserve & Receivables Spotlight Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 mb-5">
        <div className="p-4 rounded-2xl bg-black/40 border border-white/[0.08]">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            PENDING RECEIVABLES
          </div>
          <div className="font-mono text-2xl font-extrabold text-cyan-400 mt-1">
            {formatINR(pendingReceivables)}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Across {pendingInvoices.length} active invoices
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-black/40 border border-white/[0.08]">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            18% GST LIABILITY RESERVE
          </div>
          <div className="font-mono text-2xl font-extrabold text-amber-400 mt-1">
            {formatINR(gstReserve)}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Keep aside for quarterly GST
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-black/40 border border-white/[0.08]">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            SEC 44ADA PRESUMPTIVE TAX
          </div>
          <div className="font-mono text-2xl font-extrabold text-purple-400 mt-1">
            {formatINR(incomeTaxReserve)}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Deemed 50% profit tax cushion
          </div>
        </div>
      </div>

      {/* Add Invoice Form */}
      <AnimatePresence>
        {showAdd && (
          <motion.form
            onSubmit={handleSubmit}
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="p-5 rounded-2xl bg-black/45 border border-white/[0.08] mb-5"
          >
            <div className="text-sm font-bold text-white mb-3">
              Create Pending Client Invoice
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-xs text-slate-300 block mb-1">
                  Client / Project Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Acme Labs"
                  value={client}
                  onChange={(e) => setClient(e.target.value)}
                  className="fintech-input"
                />
              </div>

              <div>
                <label className="text-xs text-slate-300 block mb-1">
                  Invoice Amount (₹)
                </label>
                <input
                  type="number"
                  step="any"
                  required
                  placeholder="e.g. 150000"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="fintech-input"
                />
              </div>

              <div>
                <label className="text-xs text-slate-300 block mb-1">
                  Payment Due Date
                </label>
                <input
                  type="date"
                  required
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="fintech-input"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2.5 mt-4">
              <button
                type="button"
                onClick={() => setShowAdd(false)}
                className="btn-fintech-secondary text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn-fintech-primary text-xs"
              >
                Save Invoice
              </button>
            </div>
          </motion.form>
        )}
      </AnimatePresence>

      {/* Invoice List */}
      <div className="flex flex-col gap-2.5">
        {invoices.length === 0 ? (
          <div className="py-6 text-center text-slate-400 text-xs">
            No client invoices tracked. Click "New Client Invoice" to track pending receivables.
          </div>
        ) : (
          invoices.map((inv) => {
            const isPending = inv.status === 'pending';

            return (
              <div
                key={inv.id}
                className="flex items-center justify-between p-3.5 sm:p-4 rounded-2xl bg-black/35 border border-white/[0.08] flex-wrap gap-3"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${
                    isPending ? 'bg-cyan-500/10 border-cyan-500/25 text-cyan-400' : 'bg-emerald-500/10 border-emerald-500/25 text-emerald-400'
                  }`}>
                    {isPending ? <Clock size={18} /> : <CheckCircle2 size={18} />}
                  </div>

                  <div>
                    <div className="text-sm font-bold text-white">
                      {inv.client}
                    </div>
                    <div className="text-xs text-slate-400">
                      Due by: {inv.dueDate} • {isPending ? 'Pending Payment' : 'Settled to Bank'}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className={`font-mono text-base font-extrabold ${isPending ? 'text-cyan-400' : 'text-emerald-400'}`}>
                    {formatINR(inv.amount)}
                  </div>

                  {isPending ? (
                    <motion.button
                      whileTap={{ scale: 0.95 }}
                      onClick={() => onMarkPaid(inv)}
                      className="btn-fintech-primary text-xs !py-1 !px-2.5 rounded-full"
                    >
                      <CheckCircle2 size={13} />
                      <span>Mark Paid</span>
                    </motion.button>
                  ) : (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                      PAID
                    </span>
                  )}

                  <button
                    onClick={() => onDeleteInvoice(inv.id)}
                    className="text-slate-500 hover:text-rose-400 p-1 rounded-lg transition-all cursor-pointer"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </motion.div>
  );
}
