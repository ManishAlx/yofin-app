import React from 'react';
import { motion } from 'framer-motion';
import { Award, Zap } from 'lucide-react';
import { formatINR } from '../lib/formatters';

export function FinancialHealthScore({ 
  transactions, 
  settings, 
  subscriptions, 
  mode 
}) {
  const totalIncome = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + Number(t.amount), 0) || Number(settings.monthly_income) || 95000;

  const totalExpense = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + Number(t.amount), 0);

  const needsExpense = transactions
    .filter(t => t.type === 'expense' && (t.tag === 'essential' || t.tag === 'business_opex'))
    .reduce((sum, t) => sum + Number(t.amount), 0);

  const wantsExpense = transactions
    .filter(t => t.type === 'expense' && (t.tag === 'wants' || t.tag === 'client_payout'))
    .reduce((sum, t) => sum + Number(t.amount), 0);

  const netSavings = Math.max(0, totalIncome - totalExpense);
  const savingsPercent = totalIncome > 0 ? Math.round((netSavings / totalIncome) * 100) : 0;
  const needsPercent = totalIncome > 0 ? Math.round((needsExpense / totalIncome) * 100) : 0;
  const wantsPercent = totalIncome > 0 ? Math.round((wantsExpense / totalIncome) * 100) : 0;

  const leakCount = subscriptions.filter(s => s.mode === mode && s.is_active && s.leak_warning).length;

  let score = 300;
  score += Math.min(250, Math.round(savingsPercent * 8));

  if (wantsPercent <= 30) {
    score += 200;
  } else {
    score += Math.max(0, 200 - (wantsPercent - 30) * 6);
  }

  if (needsPercent <= 50) {
    score += 150;
  } else {
    score += Math.max(0, 150 - (needsPercent - 50) * 4);
  }

  score = Math.max(300, score - leakCount * 35);
  score = Math.min(900, Math.max(300, score));

  let tier = 'EXCELLENT';
  let tierColor = '#00F5A0';
  let badgeClass = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
  let tierAdvice = 'Your financial discipline is top 5%! Zero critical vulnerabilities detected.';

  if (score < 580) {
    tier = 'CRITICAL BURN';
    tierColor = '#FF4757';
    badgeClass = 'bg-rose-500/10 text-rose-400 border-rose-500/30';
    tierAdvice = 'Discretionary spending is dangerously high. Immediate budget freeze recommended!';
  } else if (score < 680) {
    tier = 'MODERATE HEALTH';
    tierColor = '#FFB800';
    badgeClass = 'bg-amber-500/10 text-amber-400 border-amber-500/30';
    tierAdvice = 'Wants & lifestyle orders are eating into your savings buffer. Moderate spending.';
  } else if (score < 780) {
    tier = 'HEALTHY RUNWAY';
    tierColor = '#00D8F6';
    badgeClass = 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30';
    tierAdvice = 'Good baseline. Eliminate zombie subscriptions to reach the Elite 800+ tier!';
  }

  const scoreRatio = (score - 300) / 600;

  return (
    <motion.div 
      whileHover={{ y: -2 }}
      className="glass-card p-6 sm:p-7 my-6 relative overflow-hidden"
    >
      {/* Background Radial Glow */}
      <div 
        className="absolute -top-16 -left-16 w-60 h-60 rounded-full blur-3xl opacity-15 pointer-events-none transition-colors duration-500"
        style={{ backgroundColor: tierColor }}
      />

      {/* Top Header */}
      <div className="flex items-center justify-between flex-wrap gap-3 mb-6 relative z-10">
        <div className="flex items-center gap-3.5">
          <div 
            className="w-11 h-11 rounded-xl flex items-center justify-center border transition-transform hover:scale-105"
            style={{ 
              backgroundColor: `${tierColor}18`, 
              borderColor: `${tierColor}40`,
              boxShadow: `0 0 16px ${tierColor}25`
            }}
          >
            <Award size={24} style={{ color: tierColor }} />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h3 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
                CRED-Style Financial Health Score
              </h3>
              <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border uppercase tracking-wider ${badgeClass}`}>
                {tier}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Holistic credit & survival rating based on the Indian 50-30-20 wealth matrix
            </p>
          </div>
        </div>

        <div className="text-xs text-slate-400 font-medium">
          Benchmark Scale: 300 – 900 Points
        </div>
      </div>

      {/* Dial Score & 50-30-20 Breakdown Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 items-center relative z-10">
        {/* Speedometer Score Display */}
        <div className="flex flex-col items-center justify-center p-6 rounded-2xl bg-black/40 border border-white/[0.08] text-center">
          <div className="relative w-44 h-28 overflow-hidden">
            <svg viewBox="0 0 100 60" className="w-full h-full">
              <path
                d="M 10 50 A 40 40 0 0 1 90 50"
                fill="none"
                stroke="rgba(255, 255, 255, 0.08)"
                strokeWidth="10"
                strokeLinecap="round"
              />
              <motion.path
                d="M 10 50 A 40 40 0 0 1 90 50"
                fill="none"
                stroke={tierColor}
                strokeWidth="10"
                strokeLinecap="round"
                strokeDasharray="126"
                initial={{ strokeDashoffset: 126 }}
                animate={{ strokeDashoffset: 126 - (126 * scoreRatio) }}
                transition={{ duration: 1.2, ease: 'easeOut' }}
              />
            </svg>
            <div className="absolute bottom-1 inset-x-0 flex flex-col items-center">
              <div className="font-mono text-4xl font-extrabold text-white leading-none">
                {score}
              </div>
              <div className="text-[10px] font-bold tracking-widest uppercase mt-1" style={{ color: tierColor }}>
                {tier}
              </div>
            </div>
          </div>

          <div className="text-xs text-slate-300 mt-3 font-medium max-w-sm">
            {tierAdvice}
          </div>
        </div>

        {/* 50-30-20 Rule Allocation */}
        <div className="flex flex-col gap-3.5 p-5 sm:p-6 rounded-2xl bg-black/40 border border-white/[0.08]">
          <div className="flex items-center justify-between text-xs mb-1">
            <span className="font-bold text-white">
              The 50 - 30 - 20 Rule Allocation
            </span>
            <span className="text-slate-400 font-mono">
              Inflow: {formatINR(totalIncome)}
            </span>
          </div>

          {/* Needs */}
          <div>
            <div className="flex justify-between text-xs mb-1.5 font-medium">
              <span className="text-slate-300">🟢 Needs (Rent, Bills, Food)</span>
              <span className={`font-mono ${needsPercent > 50 ? 'text-rose-400' : 'text-slate-200'}`}>
                {formatINR(needsExpense)} ({needsPercent}% / max 50%)
              </span>
            </div>
            <div className="h-2 bg-white/[0.06] rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(100, needsPercent)}%` }}
                transition={{ duration: 0.8 }}
                className={`h-full rounded-full ${needsPercent > 50 ? 'bg-rose-500' : 'bg-emerald-400'}`}
              />
            </div>
          </div>

          {/* Wants */}
          <div>
            <div className="flex justify-between text-xs mb-1.5 font-medium">
              <span className="text-slate-300">🟡 Wants (Dining, Shopping)</span>
              <span className={`font-mono ${wantsPercent > 30 ? 'text-rose-400' : 'text-slate-200'}`}>
                {formatINR(wantsExpense)} ({wantsPercent}% / max 30%)
              </span>
            </div>
            <div className="h-2 bg-white/[0.06] rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(100, wantsPercent)}%` }}
                transition={{ duration: 0.8, delay: 0.1 }}
                className={`h-full rounded-full ${wantsPercent > 30 ? 'bg-rose-500' : 'bg-amber-400'}`}
              />
            </div>
          </div>

          {/* Savings */}
          <div>
            <div className="flex justify-between text-xs mb-1.5 font-medium">
              <span className="text-slate-300">🟣 Savings & Investments</span>
              <span className={`font-mono ${savingsPercent >= 20 ? 'text-purple-400' : 'text-amber-400'}`}>
                {formatINR(netSavings)} ({savingsPercent}% / min 20%)
              </span>
            </div>
            <div className="h-2 bg-white/[0.06] rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(100, savingsPercent)}%` }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="h-full rounded-full bg-purple-500"
              />
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
