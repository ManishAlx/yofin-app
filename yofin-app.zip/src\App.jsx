import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Navbar } from './components/Navbar';
import { ModeSwitcher } from './components/ModeSwitcher';
import { FintechMascot } from './components/FintechMascot';
import { PaydaySurvivalCalculator } from './components/PaydaySurvivalCalculator';
import { MetricCards } from './components/MetricCards';
import { FinancialHealthScore } from './components/FinancialHealthScore';
import { BudgetAlerts } from './components/BudgetAlerts';
import { SalaryDelayShield } from './components/SalaryDelayShield';
import { ImpulseCoolingVault } from './components/ImpulseCoolingVault';
import { InvoiceTracker } from './components/InvoiceTracker';
import { GoalVault } from './components/GoalVault';
import { CreditCardTrapCalculator } from './components/CreditCardTrapCalculator';
import { TransactionModal } from './components/TransactionModal';
import { TransactionList } from './components/TransactionList';
import { SubscriptionStopper } from './components/SubscriptionStopper';
import { FinancialCharts } from './components/FinancialCharts';
import { SupabaseConfigModal } from './components/SupabaseConfigModal';
import { SqlSchemaModal } from './components/SqlSchemaModal';
import { AuthModal } from './components/AuthModal';
import { useAuth } from './context/AuthContext';
import { useToast } from './context/ToastContext';
import { Plus, Zap } from 'lucide-react';
import { sounds } from './lib/soundEffects';
import { 
  supabase, 
  isConfigured, 
  testSupabaseConnection 
} from './lib/supabase';
import { 
  INITIAL_SALARIED_TRANSACTIONS, 
  INITIAL_BUSINESS_TRANSACTIONS, 
  INITIAL_SUBSCRIPTIONS, 
  INITIAL_SETTINGS 
} from './lib/defaultData';

export function App() {
  const { user } = useAuth();
  const { addToast } = useToast();
  const [mode, setMode] = useState('salaried'); // 'salaried' | 'business'
  const [theme, setTheme] = useState(() => {
    return localStorage.getItem('yofin_theme') || 'dark';
  });
  const [transactions, setTransactions] = useState([]);
  const [subscriptions, setSubscriptions] = useState([]);
  const [settings, setSettings] = useState(INITIAL_SETTINGS.salaried);
  const [supabaseStatus, setSupabaseStatus] = useState({ connected: false, message: '' });

  // Sync theme attribute on document root
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('yofin_theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => (prev === 'dark' ? 'light' : 'dark'));
    sounds.playSuccess();
    addToast(`Switched to ${theme === 'dark' ? 'Light' : 'Dark'} mode`, 'info');
  };

  // Invoices & Vault
  const [invoices, setInvoices] = useState([
    {
      id: 'inv-1',
      client: 'Acme Fintech Corp (Mobile UI)',
      amount: 150000,
      dueDate: new Date(Date.now() + 6 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      status: 'pending',
      isGst: true
    },
    {
      id: 'inv-2',
      client: 'Starlight SaaS (Backend Integration)',
      amount: 80000,
      dueDate: new Date(Date.now() + 18 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      status: 'pending',
      isGst: true
    }
  ]);

  const [vaultData, setVaultData] = useState({ saved: 65000, target: 150000 });

  // Modals state
  const [isTxModalOpen, setIsTxModalOpen] = useState(false);
  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);
  const [isSqlModalOpen, setIsSqlModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  // Check Supabase connection on load
  useEffect(() => {
    testSupabaseConnection().then(res => {
      setSupabaseStatus({ connected: res.success, message: res.message });
    });
  }, []);

  // Keyboard shortcut: Press "N" or "Ctrl+K" to open quick add
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) return;
      if (e.key === 'n' || e.key === 'N' || (e.ctrlKey && e.key === 'k') || (e.metaKey && e.key === 'k')) {
        e.preventDefault();
        setIsTxModalOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Initialize data from LocalStorage or Default seeds
  useEffect(() => {
    const savedTx = localStorage.getItem(`yofin_tx_${mode}`);
    if (savedTx) {
      try {
        setTransactions(JSON.parse(savedTx));
      } catch (e) {
        setTransactions(mode === 'salaried' ? INITIAL_SALARIED_TRANSACTIONS : INITIAL_BUSINESS_TRANSACTIONS);
      }
    } else {
      setTransactions(mode === 'salaried' ? INITIAL_SALARIED_TRANSACTIONS : INITIAL_BUSINESS_TRANSACTIONS);
    }

    const savedSubs = localStorage.getItem('yofin_subscriptions');
    if (savedSubs) {
      try {
        setSubscriptions(JSON.parse(savedSubs));
      } catch (e) {
        setSubscriptions(INITIAL_SUBSCRIPTIONS);
      }
    } else {
      setSubscriptions(INITIAL_SUBSCRIPTIONS);
    }

    const savedSettings = localStorage.getItem(`yofin_settings_${mode}`);
    if (savedSettings) {
      try {
        setSettings(JSON.parse(savedSettings));
      } catch (e) {
        setSettings(INITIAL_SETTINGS[mode]);
      }
    } else {
      setSettings(INITIAL_SETTINGS[mode]);
    }

    const savedInvoices = localStorage.getItem('yofin_invoices');
    if (savedInvoices) {
      try {
        setInvoices(JSON.parse(savedInvoices));
      } catch (e) {}
    }

    const savedVault = localStorage.getItem('yofin_vault');
    if (savedVault) {
      try {
        setVaultData(JSON.parse(savedVault));
      } catch (e) {}
    }
  }, [mode]);

  // If Supabase is connected, optionally fetch from Supabase
  useEffect(() => {
    if (isConfigured && supabase && user) {
      supabase
        .from('transactions')
        .select('*')
        .eq('mode', mode)
        .order('date', { ascending: false })
        .then(({ data, error }) => {
          if (!error && data && data.length > 0) {
            setTransactions(data);
          }
        });
    }
  }, [mode, user]);

  // Handlers for transactions
  const handleAddTransaction = async (newTx) => {
    const updated = [newTx, ...transactions];
    setTransactions(updated);
    localStorage.setItem(`yofin_tx_${mode}`, JSON.stringify(updated));

    // Update settings available balance automatically
    const delta = newTx.type === 'income' ? newTx.amount : -newTx.amount;
    const newBalance = Math.max(0, Number(settings.available_balance) + delta);
    const updatedSettings = { ...settings, available_balance: newBalance };
    setSettings(updatedSettings);
    localStorage.setItem(`yofin_settings_${mode}`, JSON.stringify(updatedSettings));

    sounds.playSuccess();
    addToast(`Recorded: ${newTx.title} (₹${newTx.amount})`, 'success');

    // Sync to Supabase if connected
    if (isConfigured && supabase && user) {
      try {
        await supabase.from('transactions').insert([{
          ...newTx,
          user_id: user.id
        }]);
      } catch (e) {
        console.warn('Supabase insert failed, kept in local ledger:', e);
      }
    }
  };

  const handleDeleteTransaction = async (id) => {
    const target = transactions.find(t => t.id === id);
    const updated = transactions.filter(t => t.id !== id);
    setTransactions(updated);
    localStorage.setItem(`yofin_tx_${mode}`, JSON.stringify(updated));

    sounds.playWarning();
    addToast(`Deleted ${target?.title || 'record'}`, 'warning');

    if (isConfigured && supabase) {
      try {
        await supabase.from('transactions').delete().eq('id', id);
      } catch (e) {
        console.warn('Supabase delete failed:', e);
      }
    }
  };

  // Handlers for subscriptions
  const handleToggleSubActive = (id) => {
    const updated = subscriptions.map(s => {
      if (s.id === id) {
        const nextState = !s.is_active;
        sounds.playSuccess();
        addToast(nextState ? `Reactivated ${s.name}` : `Cancelled subscription: ${s.name}`, nextState ? 'info' : 'success');
        return { ...s, is_active: nextState, leak_warning: null };
      }
      return s;
    });
    setSubscriptions(updated);
    localStorage.setItem('yofin_subscriptions', JSON.stringify(updated));
  };

  const handleDeleteSub = (id) => {
    const updated = subscriptions.filter(s => s.id !== id);
    setSubscriptions(updated);
    localStorage.setItem('yofin_subscriptions', JSON.stringify(updated));
    addToast('Removed subscription from tracking', 'info');
  };

  const handleAddSub = (newSub) => {
    const updated = [newSub, ...subscriptions];
    setSubscriptions(updated);
    localStorage.setItem('yofin_subscriptions', JSON.stringify(updated));
    sounds.playSuccess();
    addToast(`Added ${newSub.name} to subscription stopper`, 'success');
  };

  // Handlers for Settings
  const handleUpdateSettings = (newSettings) => {
    setSettings(newSettings);
    localStorage.setItem(`yofin_settings_${mode}`, JSON.stringify(newSettings));
    sounds.playSuccess();
    addToast('Survival calculation parameters updated', 'success');
  };

  // Handlers for Invoices
  const handleAddInvoice = (newInv) => {
    const updated = [newInv, ...invoices];
    setInvoices(updated);
    localStorage.setItem('yofin_invoices', JSON.stringify(updated));
    sounds.playSuccess();
    addToast(`Invoice for ${newInv.client} created`, 'success');
  };

  const handleMarkInvoicePaid = (inv) => {
    const updated = invoices.map(i => i.id === inv.id ? { ...i, status: 'paid' } : i);
    setInvoices(updated);
    localStorage.setItem('yofin_invoices', JSON.stringify(updated));

    // Automatically record an income credit transaction in the ledger!
    handleAddTransaction({
      id: `tx-${Date.now()}`,
      title: `Invoice Payment: ${inv.client}`,
      amount: inv.amount,
      type: 'income',
      category: 'Client Retainer',
      tag: 'essential',
      mode: 'business',
      payment_method: 'Wire Transfer',
      date: new Date().toISOString().split('T')[0],
      is_recurring: false
    });

    sounds.playSuccess();
    addToast(`Settled ₹${inv.amount} from ${inv.client} to Bank Balance!`, 'success');
  };

  const handleDeleteInvoice = (id) => {
    const updated = invoices.filter(i => i.id !== id);
    setInvoices(updated);
    localStorage.setItem('yofin_invoices', JSON.stringify(updated));
    addToast('Invoice deleted', 'warning');
  };

  // Handlers for Vault
  const handleUpdateVault = (newData) => {
    setVaultData(newData);
    localStorage.setItem('yofin_vault', JSON.stringify(newData));
    sounds.playSuccess();
    addToast('Emergency vault updated', 'success');
  };

  // Effective days for safe daily limit benchmark
  const today = new Date();
  const currentDay = today.getDate();
  const paydayDay = settings.payday_day || 1;
  let daysToPayday = 0;
  if (currentDay < paydayDay) {
    daysToPayday = paydayDay - currentDay;
  } else if (currentDay > paydayDay) {
    const nextMonth = new Date(today.getFullYear(), today.getMonth() + 1, paydayDay);
    daysToPayday = Math.ceil(Math.abs(nextMonth - today) / (1000 * 60 * 60 * 24));
  } else {
    daysToPayday = 1;
  }
  const effectiveFunds = Math.max(0, Number(settings.available_balance) - Number(settings.pending_fixed_bills));
  const safeDailyLimit = Math.max(100, Math.floor(effectiveFunds / Math.max(1, daysToPayday)));

  return (
    <div className="min-h-screen flex flex-col relative text-slate-100 overflow-x-hidden">
      {/* Subtle ambient dynamic background glows */}
      <div className="fixed top-0 left-1/4 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="fixed top-1/3 right-10 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="fixed bottom-10 left-10 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl pointer-events-none -z-10" />

      {/* Top Navbar */}
      <Navbar
        mode={mode}
        theme={theme}
        onToggleTheme={toggleTheme}
        onOpenSettings={() => setIsConfigModalOpen(true)}
        onOpenSqlSchema={() => setIsSqlModalOpen(true)}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        supabaseStatus={supabaseStatus}
      />

      {/* Main App Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-24 w-full flex-1 space-y-6">
        {/* Mode Switcher */}
        <ModeSwitcher mode={mode} setMode={setMode} />

        {/* Interactive FinTech Bot/Character Mascot ("Finny") with animated 3D symbols & speech */}
        <FintechMascot
          safeDailyLimit={safeDailyLimit}
          mode={mode}
          daysToPayday={daysToPayday}
        />

        {/* 1. THE USP: Payday Survival & Daily Burn Calculator with Car Fuel Tank Gauge */}
        <PaydaySurvivalCalculator
          mode={mode}
          settings={settings}
          onUpdateSettings={handleUpdateSettings}
        />

        {/* 2. Top Financial Metrics */}
        <MetricCards
          mode={mode}
          settings={settings}
          transactions={transactions}
          onQuickAdd={() => setIsTxModalOpen(true)}
        />

        {/* 3. CRED-Style Financial Health Score (300-900) & 50-30-20 Rule */}
        <FinancialHealthScore
          transactions={transactions}
          settings={settings}
          subscriptions={subscriptions}
          mode={mode}
        />

        {/* 4. SMART CATEGORY BUDGET ALERTS */}
        <BudgetAlerts
          transactions={transactions}
          mode={mode}
          onAddToast={addToast}
        />

        {/* 4. EMERGENCY SALARY DELAY SHIELD PROTOCOL */}
        <SalaryDelayShield
          mode={mode}
          settings={settings}
          onAddToast={addToast}
        />

        {/* 5. IMPULSE PURCHASE REGRET PREDICTOR & 24-HOUR COOLING OFF VAULT */}
        <ImpulseCoolingVault
          safeDailyLimit={safeDailyLimit}
          onLogExpense={handleAddTransaction}
          onAddToast={addToast}
        />

        {/* 6. CREDIT CARD MINIMUM DUE TRAP DETECTOR */}
        <CreditCardTrapCalculator />

        {/* 7. MODE SPECIFIC WORKFLOWS: Business Invoices vs Salaried Goal Vault */}
        {mode === 'business' ? (
          <InvoiceTracker
            invoices={invoices}
            onAddInvoice={handleAddInvoice}
            onMarkPaid={handleMarkInvoicePaid}
            onDeleteInvoice={handleDeleteInvoice}
          />
        ) : (
          <GoalVault
            settings={settings}
            vaultData={vaultData}
            onUpdateVault={handleUpdateVault}
          />
        )}

        {/* 8. Visual Charts (Category breakdown, Month-over-Month, Daily vs Cap) */}
        <FinancialCharts
          transactions={transactions}
          mode={mode}
          safeDailyLimit={safeDailyLimit}
        />

        {/* 9. Money Leaks & Unused Subscription Stopper */}
        <SubscriptionStopper
          subscriptions={subscriptions}
          onToggleActive={handleToggleSubActive}
          onDeleteSubscription={handleDeleteSub}
          onAddSubscription={handleAddSub}
          mode={mode}
        />

        {/* 10. Complete Cashflow Ledger & Filterable Transaction List */}
        <TransactionList
          transactions={transactions}
          onDeleteTransaction={handleDeleteTransaction}
          onOpenAddModal={() => setIsTxModalOpen(true)}
          mode={mode}
        />
      </main>

      {/* FLOATING ACTION BUTTON (FAB) FOR RAPID LOGGING */}
      <motion.button
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.92 }}
        onClick={() => setIsTxModalOpen(true)}
        className="fixed bottom-6 right-6 sm:bottom-8 sm:right-8 z-40 w-14 h-14 rounded-full bg-gradient-to-r from-emerald-400 to-teal-400 text-slate-950 font-bold shadow-glow-emerald flex items-center justify-center border border-white/20 hover:brightness-110 transition-all group"
        title="Quick Log Transaction (Press 'N' or Ctrl+K)"
      >
        <Plus size={26} strokeWidth={2.6} className="group-hover:rotate-90 transition-transform duration-300" />
      </motion.button>

      {/* Footer */}
      <footer className="border-t border-white/10 py-6 px-4 bg-slate-950/80 backdrop-blur-md text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white tracking-wide">Yofin</span>
            <span className="text-slate-600">•</span>
            <span>Ultra-Modern FinTech Runway & Survival Engine</span>
          </div>
          <div className="flex items-center gap-2 text-[11px] text-slate-400">
            <span>Quick Log:</span>
            <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white font-mono border border-white/10">N</kbd>
            <span>or</span>
            <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white font-mono border border-white/10">Ctrl+K</kbd>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <TransactionModal
        isOpen={isTxModalOpen}
        onClose={() => setIsTxModalOpen(false)}
        onAddTransaction={handleAddTransaction}
        mode={mode}
      />

      <SupabaseConfigModal
        isOpen={isConfigModalOpen}
        onClose={() => setIsConfigModalOpen(false)}
        onConfigSaved={() => {
          testSupabaseConnection().then(res => {
            setSupabaseStatus({ connected: res.success, message: res.message });
          });
        }}
      />

      <SqlSchemaModal
        isOpen={isSqlModalOpen}
        onClose={() => setIsSqlModalOpen(false)}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />
    </div>
  );
}

export default App;
