import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { CreditCard, AlertTriangle, TrendingDown } from 'lucide-react';
import { formatINR } from '../lib/formatters';

export function CreditCardTrapCalculator() {
  const [balance, setBalance] = useState(48000);
  const [apr, setApr] = useState(42);
  const [minDuePercent, setMinDuePercent] = useState(5);

  const numericBalance = parseFloat(balance) || 0;
  const numericApr = parseFloat(apr) || 42;
  const minDueAmount = Math.max(500, Math.round(numericBalance * (minDuePercent / 100)));

  const monthlyRate = (numericApr / 100) / 12;
  const monthsToPayoffMin = Math.round(Math.log(1 / (1 - (numericBalance * monthlyRate) / minDueAmount)) / Math.log(1 + monthlyRate)) || 64;
  const totalInterestMin = Math.round(numericBalance * 0.48 * (monthsToPayoffMin / 12) * 0.6);

  const smartPayment = Math.max(3000, Math.round(numericBalance * 0.15));
  const monthsSmart = Math.ceil(numericBalance / smartPayment);
  const totalInterestSmart = Math.round(numericBalance * monthlyRate * (monthsSmart / 2));

  return (
    <motion.div 
      whileHover={{ y: -2 }}
      className="glass-card p-6 sm:p-7 my-6"
    >
      {/* Header */}
      <div className="flex items-center gap-3.5 mb-5">
        <div className="w-11 h-11 rounded-xl bg-amber-500/15 border border-amber-500/35 text-amber-400 flex items-center justify-center shrink-0">
          <CreditCard size={22} />
        </div>
        <div>
          <div className="flex items-center gap-2.5">
            <h3 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
              Credit Card "Minimum Due" Trap Detector
            </h3>
            <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider bg-amber-500/15 text-amber-400 border border-amber-500/30">
              42% APR AUDIT
            </span>
          </div>
          <p className="text-xs text-slate-400">
            Reveals how Indian banks trap cardholders in 5-year debt cycles when only paying minimum due
          </p>
        </div>
      </div>

      {/* Input row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 mb-5">
        <div>
          <label className="text-xs text-slate-300 block mb-1">
            Total Card Outstanding (₹)
          </label>
          <input
            type="number"
            value={balance}
            onChange={(e) => setBalance(e.target.value === '' ? '' : Number(e.target.value))}
            placeholder="e.g. 48000"
            className="fintech-input"
          />
        </div>

        <div>
          <label className="text-xs text-slate-300 block mb-1">
            Annual Interest Rate (APR %)
          </label>
          <input
            type="number"
            value={apr}
            onChange={(e) => setApr(e.target.value === '' ? '' : Number(e.target.value))}
            placeholder="Typically 42%"
            className="fintech-input"
          />
        </div>

        <div>
          <label className="text-xs text-slate-300 block mb-1">
            Bank Minimum Due Required
          </label>
          <div className="font-mono text-sm font-bold text-amber-400 px-4 py-2.5 rounded-xl bg-black/40 border border-white/[0.08] flex items-center justify-between">
            <span>{formatINR(minDueAmount)}</span>
            <span className="text-xs text-slate-400 font-sans font-medium">(5%)</span>
          </div>
        </div>
      </div>

      {/* Comparative Trap Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* OPTION A: The Trap */}
        <div className="p-5 rounded-2xl bg-rose-500/[0.07] border border-rose-500/30 flex flex-col justify-between">
          <div>
            <div className="text-xs font-bold text-rose-400 uppercase tracking-wider">
              TRAP: PAYING MINIMUM DUE ONLY
            </div>
            <div className="font-mono text-2xl sm:text-3xl font-extrabold text-rose-400 mt-1">
              +{formatINR(totalInterestMin)}
            </div>
            <div className="text-xs text-slate-300 mt-1">
              Pure waste paid in compounding bank interest!
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-rose-500/20 text-xs text-white">
            Time to Debt-Free: <strong className="font-mono text-rose-400 font-bold ml-1">~{monthsToPayoffMin} Months (5.3 Years!)</strong>
          </div>
        </div>

        {/* OPTION B: The Smart Fix */}
        <div className="p-5 rounded-2xl bg-emerald-500/[0.07] border border-emerald-500/30 flex flex-col justify-between">
          <div>
            <div className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
              THE FIX: FIXED {formatINR(smartPayment)}/MO PAYOFF
            </div>
            <div className="font-mono text-2xl sm:text-3xl font-extrabold text-emerald-400 mt-1">
              {formatINR(totalInterestSmart)}
            </div>
            <div className="text-xs text-slate-300 mt-1">
              Saves you <strong className="text-emerald-400 font-mono">{formatINR(totalInterestMin - totalInterestSmart)}</strong> in cash!
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-emerald-500/20 text-xs text-white">
            Time to Debt-Free: <strong className="font-mono text-emerald-400 font-bold ml-1">Only {monthsSmart} Months</strong>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
