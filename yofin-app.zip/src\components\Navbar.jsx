import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Zap, 
  Database, 
  Code2, 
  LogOut, 
  User, 
  SlidersHorizontal, 
  Sparkles,
  ChevronDown,
  Sun,
  Moon
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export function Navbar({ 
  mode, 
  theme = 'dark',
  onToggleTheme,
  onOpenSettings, 
  onOpenSqlSchema, 
  onOpenAuth,
  supabaseStatus 
}) {
  const { user, isDemo, signOut } = useAuth();
  const [dropdownOpen, setDropdownOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 backdrop-blur-xl border-b border-white/[0.08] bg-[#07080B]/85 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 py-3 flex items-center justify-between gap-4">
        {/* Brand / Logo */}
        <div className="flex items-center gap-3.5">
          <motion.div 
            whileHover={{ scale: 1.05, rotate: 5 }}
            whileTap={{ scale: 0.95 }}
            className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#00F5A0] via-[#00D084] to-[#00D8F6] p-[1px] shadow-glow-emerald flex items-center justify-center cursor-pointer"
          >
            <div className="w-full h-full bg-[#05140D] rounded-xl flex items-center justify-center">
              <Zap size={22} className="text-[#00F5A0]" strokeWidth={2.6} />
            </div>
          </motion.div>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-100 to-[#00F5A0] bg-clip-text text-transparent">
                Yofin
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                PRO
              </span>
            </div>
            <div className="text-xs text-slate-400 flex items-center gap-1.5 font-medium">
              <span>Survival Engine</span>
              <span>•</span>
              <span className={mode === 'salaried' ? 'text-emerald-400' : 'text-cyan-400'}>
                {mode === 'salaried' ? 'Salaried Mode' : 'Business Mode'}
              </span>
            </div>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-2.5 sm:gap-3">
          {/* Theme Toggle Button (Dark/Light) */}
          <motion.button
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.95 }}
            onClick={onToggleTheme}
            className="p-2 sm:px-3 sm:py-1.5 text-xs font-semibold rounded-full border border-white/[0.08] hover:border-white/20 bg-white/[0.04] text-slate-200 transition-all flex items-center gap-1.5"
            title={`Switch to ${theme === 'dark' ? 'Light' : 'Dark'} Mode`}
          >
            {theme === 'dark' ? (
              <>
                <Sun size={15} className="text-amber-400" />
                <span className="hidden sm:inline">Light</span>
              </>
            ) : (
              <>
                <Moon size={15} className="text-cyan-400" />
                <span className="hidden sm:inline">Dark</span>
              </>
            )}
          </motion.button>

          {/* Supabase Connection Pill */}
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.96 }}
            onClick={onOpenSettings}
            className="hidden sm:flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-full border border-white/[0.08] hover:border-white/20 bg-white/[0.04] text-slate-300 transition-all"
            title="Configure Supabase Database"
          >
            <span className={`w-2 h-2 rounded-full ${supabaseStatus?.connected ? 'bg-emerald-400 shadow-[0_0_8px_#00F5A0]' : 'bg-amber-400 shadow-[0_0_8px_#FFB800]'}`} />
            <Database size={13} className="text-slate-400" />
            <span className="hidden md:inline">
              {supabaseStatus?.connected ? 'Supabase Live' : 'Supabase Demo'}
            </span>
          </motion.button>

          {/* SQL Schema Button */}
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.96 }}
            onClick={onOpenSqlSchema}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-full border border-cyan-500/25 hover:border-cyan-500/50 bg-cyan-500/10 text-cyan-300 transition-all"
          >
            <Code2 size={13} />
            <span>SQL Schema</span>
          </motion.button>

          {/* User Profile / Auth */}
          {user ? (
            <div className="relative">
              <motion.button
                whileTap={{ scale: 0.97 }}
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1 rounded-full border border-white/[0.08] hover:border-white/20 bg-white/[0.04] text-white transition-all"
              >
                <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-500 flex items-center justify-center font-bold text-xs text-white shadow-sm">
                  {(user.user_metadata?.full_name || user.email || 'U')[0].toUpperCase()}
                </div>
                <div className="hidden sm:block text-left text-xs leading-tight">
                  <div className="font-semibold truncate max-w-[100px]">
                    {user.user_metadata?.full_name || user.email?.split('@')[0]}
                  </div>
                  {isDemo && (
                    <div className="text-[10px] text-amber-400 font-medium">Guest</div>
                  )}
                </div>
                <ChevronDown size={13} className="text-slate-400" />
              </motion.button>

              <AnimatePresence>
                {dropdownOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    transition={{ duration: 0.15 }}
                    className="absolute right-0 top-full mt-2 w-56 p-1.5 rounded-2xl border border-white/[0.12] bg-[#0E1017]/95 backdrop-blur-2xl shadow-glass z-50"
                  >
                    <div className="p-2.5 border-b border-white/[0.06]">
                      <div className="text-xs font-semibold text-white">
                        {user.user_metadata?.full_name || 'User'}
                      </div>
                      <div className="text-[11px] text-slate-400 truncate">
                        {user.email}
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setDropdownOpen(false);
                        onOpenSettings();
                      }}
                      className="w-full flex items-center gap-2 p-2 mt-1 text-xs font-medium text-slate-300 hover:text-white rounded-xl hover:bg-white/[0.06] transition-all"
                    >
                      <SlidersHorizontal size={14} className="text-cyan-400" />
                      <span>Supabase Settings</span>
                    </button>

                    <button
                      onClick={() => {
                        setDropdownOpen(false);
                        signOut();
                      }}
                      className="w-full flex items-center gap-2 p-2 mt-1 text-xs font-medium text-rose-400 hover:text-rose-300 rounded-xl hover:bg-rose-500/10 transition-all"
                    >
                      <LogOut size={14} />
                      <span>Sign Out</span>
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ) : (
            <motion.button
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.96 }}
              onClick={onOpenAuth}
              className="btn-fintech-primary text-xs !py-2 !px-4"
            >
              Sign In
            </motion.button>
          )}
        </div>
      </div>
    </header>
  );
}
