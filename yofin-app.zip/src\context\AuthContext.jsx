import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase, isConfigured } from '../lib/supabase';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isDemo, setIsDemo] = useState(false);

  useEffect(() => {
    // Check if demo user was logged in
    const storedDemo = localStorage.getItem('yofin_demo_user');
    if (storedDemo) {
      try {
        const parsed = JSON.parse(storedDemo);
        setUser(parsed);
        setIsDemo(true);
        setLoading(false);
        return;
      } catch (e) {
        localStorage.removeItem('yofin_demo_user');
      }
    }

    if (isConfigured && supabase) {
      // Check current active session
      supabase.auth.getSession().then(({ data: { session } }) => {
        if (session?.user) {
          setUser(session.user);
          setIsDemo(false);
        }
        setLoading(false);
      }).catch(() => {
        setLoading(false);
      });

      // Listen for auth state changes
      const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
        if (session?.user) {
          setUser(session.user);
          setIsDemo(false);
        } else if (!localStorage.getItem('yofin_demo_user')) {
          setUser(null);
        }
      });

      return () => subscription?.unsubscribe();
    } else {
      // If not configured, auto-enable demo user for immediate great experience
      const defaultDemoUser = {
        id: 'demo-user-101',
        email: 'alex.verma@yofin.finance',
        user_metadata: {
          full_name: 'Alex Verma'
        }
      };
      localStorage.setItem('yofin_demo_user', JSON.stringify(defaultDemoUser));
      setUser(defaultDemoUser);
      setIsDemo(true);
      setLoading(false);
    }
  }, []);

  const loginDemoUser = (customName = 'Alex Verma', email = 'alex.verma@yofin.finance') => {
    const demo = {
      id: 'demo-user-101',
      email,
      user_metadata: { full_name: customName }
    };
    localStorage.setItem('yofin_demo_user', JSON.stringify(demo));
    setUser(demo);
    setIsDemo(true);
  };

  const signIn = async (email, password) => {
    if (!isConfigured || !supabase) {
      // Demo fallback login
      loginDemoUser(email.split('@')[0], email);
      return { data: { user }, error: null };
    }

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });
      if (error) throw error;
      localStorage.removeItem('yofin_demo_user');
      setIsDemo(false);
      setUser(data.user);
      return { data, error: null };
    } catch (error) {
      return { data: null, error };
    }
  };

  const signUp = async (email, password, fullName) => {
    if (!isConfigured || !supabase) {
      loginDemoUser(fullName || email.split('@')[0], email);
      return { data: { user }, error: null };
    }

    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName
          }
        }
      });
      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      return { data: null, error };
    }
  };

  const signOut = async () => {
    localStorage.removeItem('yofin_demo_user');
    setIsDemo(false);
    setUser(null);
    if (isConfigured && supabase) {
      try {
        await supabase.auth.signOut();
      } catch (e) {
        console.warn('Sign out error:', e);
      }
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        isDemo,
        signIn,
        signUp,
        signOut,
        loginDemoUser
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
