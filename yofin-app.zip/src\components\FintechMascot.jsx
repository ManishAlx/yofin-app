import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Zap, Shield, TrendingUp, Trophy, Flame, HeartHandshake } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sounds } from '../lib/soundEffects';

export function FintechMascot({ safeDailyLimit = 2190, mode = 'salaried', daysToPayday = 10, healthScore = 780 }) {
  const [mascotMood, setMascotMood] = useState('happy'); // 'happy' | 'celebrate' | 'focused' | 'alert'
  const [clickCount, setClickCount] = useState(0);

  const triggerCelebrate = () => {
    sounds.playSuccess();
    setMascotMood('celebrate');
    setClickCount(prev => prev + 1);

    confetti({
      particleCount: 45,
      spread: 60,
      origin: { y: 0.35, x: 0.5 },
      colors: ['#00F5A0', '#00D8F6', '#8B5CF6', '#FFB800', '#FF4757']
    });

    setTimeout(() => {
      setMascotMood('happy');
    }, 2800);
  };

  // Dynamic speech based on financial status
  const getSpeechMessage = () => {
    if (mascotMood === 'celebrate') {
      return "🎉 Woohoo! Wealth runway secured! Keep crushing those savings, superstar!";
    }
    if (mode === 'business') {
      return `💼 Business runway is primed! Tax reserves locked, track your client receivables!`;
    }
    if (daysToPayday <= 5) {
      return `⚡ Just ${daysToPayday} days to Salary Day! You've got ₹${safeDailyLimit.toLocaleString('en-IN')}/day to cruise comfortably!`;
    }
    return `🚀 All systems nominal! Safe daily burn capped at ₹${safeDailyLimit.toLocaleString('en-IN')}/day. Tap me for luck!`;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="relative mb-6 p-4 sm:p-5 rounded-3xl glass-card overflow-hidden border border-emerald-500/20 shadow-glow-emerald/20"
    >
      {/* Background Animated Floating Symbols */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Floating ₹ Coin 1 */}
        <motion.div
          animate={{
            y: [0, -12, 0],
            rotate: [0, 8, -8, 0],
          }}
          transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute top-2 right-12 w-8 h-8 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-200 border border-amber-300/40 flex items-center justify-center font-bold text-amber-950 text-xs shadow-lg shadow-amber-500/20 opacity-70"
        >
          ₹
        </motion.div>

        {/* Floating Shield */}
        <motion.div
          animate={{
            y: [0, 10, 0],
            rotate: [0, -10, 10, 0],
          }}
          transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
          className="absolute bottom-2 right-32 text-cyan-400/50"
        >
          <Shield size={24} />
        </motion.div>

        {/* Floating Sparkle */}
        <motion.div
          animate={{
            scale: [0.8, 1.2, 0.8],
            opacity: [0.3, 0.8, 0.3],
          }}
          transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut', delay: 0.5 }}
          className="absolute top-4 right-1/3 text-emerald-400/60"
        >
          <Sparkles size={20} />
        </motion.div>

        {/* Floating Gem */}
        <motion.div
          animate={{
            y: [0, -8, 0],
            rotate: [0, 15, 0],
          }}
          transition={{ duration: 5.5, repeat: Infinity, ease: 'easeInOut', delay: 2 }}
          className="absolute bottom-3 left-1/3 text-purple-400/40"
        >
          <Zap size={20} />
        </motion.div>
      </div>

      <div className="relative z-10 flex flex-col sm:flex-row items-center gap-4 sm:gap-6">
        {/* INTERACTIVE 3D FINTECH MASCOT AVATAR ("FINNY") */}
        <motion.div
          whileHover={{ scale: 1.08 }}
          whileTap={{ scale: 0.95 }}
          onClick={triggerCelebrate}
          className="relative cursor-pointer select-none shrink-0 group"
          title="Click to high-five Finny & get celebratory confetti!"
        >
          {/* Glowing Aura Ring */}
          <div className="absolute inset-0 rounded-full bg-gradient-to-r from-emerald-400 via-cyan-400 to-teal-400 blur-lg opacity-40 group-hover:opacity-80 transition-opacity animate-pulse-subtle" />

          {/* Mascot SVG Body */}
          <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-emerald-400/40 shadow-2xl flex items-center justify-center p-2 overflow-hidden">
            <svg
              viewBox="0 0 100 100"
              className="w-full h-full drop-shadow-md"
            >
              {/* Antenna / Light */}
              <motion.circle
                cx="50"
                cy="14"
                r="4"
                fill="#00F5A0"
                animate={{
                  opacity: [0.5, 1, 0.5],
                  scale: [1, 1.2, 1]
                }}
                transition={{ duration: 1.5, repeat: Infinity }}
              />
              <line x1="50" y1="18" x2="50" y2="28" stroke="#00F5A0" strokeWidth="2.5" strokeLinecap="round" />

              {/* Bot Head / Body */}
              <rect
                x="20"
                y="28"
                width="60"
                height="54"
                rx="16"
                fill="url(#botGrad)"
                stroke="#00D8F6"
                strokeWidth="2.5"
              />

              {/* Ears / Headset */}
              <rect x="13" y="44" width="7" height="20" rx="3.5" fill="#00D8F6" />
              <rect x="80" y="44" width="7" height="20" rx="3.5" fill="#00D8F6" />

              {/* Visor Screen */}
              <rect
                x="28"
                y="38"
                width="44"
                height="22"
                rx="8"
                fill="#050811"
                stroke="#00F5A0"
                strokeWidth="1.5"
              />

              {/* Eyes Animation */}
              {mascotMood === 'celebrate' ? (
                // Happy Arc Eyes (winking celebration)
                <g stroke="#00F5A0" strokeWidth="3" strokeLinecap="round" fill="none">
                  <path d="M 36 50 Q 42 43 48 50" />
                  <path d="M 54 50 Q 60 43 66 50" />
                </g>
              ) : (
                // Neon Glowing Round Eyes
                <g fill="#00F5A0">
                  <motion.circle
                    cx="42"
                    cy="49"
                    r="4.5"
                    animate={{ scaleY: [1, 1, 0.1, 1] }}
                    transition={{ duration: 3, repeat: Infinity, times: [0, 0.85, 0.9, 1] }}
                  />
                  <motion.circle
                    cx="58"
                    cy="49"
                    r="4.5"
                    animate={{ scaleY: [1, 1, 0.1, 1] }}
                    transition={{ duration: 3, repeat: Infinity, times: [0, 0.85, 0.9, 1] }}
                  />
                </g>
              )}

              {/* Smile / Mouth */}
              <motion.path
                d={mascotMood === 'celebrate' ? "M 42 68 Q 50 76 58 68" : "M 44 68 Q 50 73 56 68"}
                stroke="#00F5A0"
                strokeWidth="2.5"
                strokeLinecap="round"
                fill="none"
              />

              {/* Cheeks */}
              <circle cx="34" cy="62" r="2.5" fill="#FF4757" opacity="0.6" />
              <circle cx="66" cy="62" r="2.5" fill="#FF4757" opacity="0.6" />

              <defs>
                <linearGradient id="botGrad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#1E293B" />
                  <stop offset="100%" stopColor="#0F172A" />
                </linearGradient>
              </defs>
            </svg>

            {/* Tap indicator badge */}
            <span className="absolute -bottom-1 -right-1 px-1.5 py-0.5 rounded-full bg-emerald-400 text-slate-950 font-black text-[9px] shadow-sm">
              TAP
            </span>
          </div>
        </motion.div>

        {/* Mascot Speech Bubble & Live Runway Stats */}
        <div className="flex-1 text-center sm:text-left">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold mb-2">
            <Flame size={14} className="text-amber-400 animate-bounce" />
            <span>FINNY • AI FINANCIAL RUNWAY GUARDIAN</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
          </div>

          <AnimatePresence mode="wait">
            <motion.p
              key={mascotMood + clickCount}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              className="text-sm sm:text-base font-medium text-slate-200 leading-relaxed max-w-2xl"
            >
              "{getSpeechMessage()}"
            </motion.p>
          </AnimatePresence>

          {/* Quick Badges / Micro Stats */}
          <div className="mt-3 flex flex-wrap items-center justify-center sm:justify-start gap-2 text-xs">
            <div className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-slate-300 flex items-center gap-1.5">
              <Trophy size={13} className="text-amber-400" />
              <span>Streak: <strong className="text-white">14 Days</strong> (Zero Overspend)</span>
            </div>

            <div className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-slate-300 flex items-center gap-1.5">
              <TrendingUp size={13} className="text-emerald-400" />
              <span>Score: <strong className="text-emerald-400">{healthScore}/900</strong></span>
            </div>

            <div className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-slate-300 flex items-center gap-1.5">
              <HeartHandshake size={13} className="text-cyan-400" />
              <span>Status: <strong className="text-cyan-300">{mode === 'salaried' ? 'Salaried Ace' : 'SaaS Pro'}</strong></span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
