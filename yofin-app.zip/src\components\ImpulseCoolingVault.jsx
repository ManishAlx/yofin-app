import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Lock, 
  CheckCircle2, 
  Clock, 
  Gift
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { formatINR } from '../lib/formatters';
import { sounds } from '../lib/soundEffects';

export function ImpulseCoolingVault({ 
  safeDailyLimit = 1200, 
  onLogExpense, 
  onAddToast 
}) {
  const [itemName, setItemName] = useState('');
  const [itemPrice, setItemPrice] = useState('');
  const [coolingItems, setCoolingItems] = useState([
    {
      id: 'cool-1',
      name: 'Sony Noise Cancelling Headphones',
      price: 18990,
      lockedAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
      hoursRemaining: 18,
      daysOfDailyAllowance: 15.8
    },
    {
      id: 'cool-2',
      name: 'Nike Air Max Sneakers',
      price: 8495,
      lockedAt: new Date(Date.now() - 20 * 60 * 60 * 1000).toISOString(),
      hoursRemaining: 4,
      daysOfDailyAllowance: 7.0
    }
  ]);

  const [totalResisted, setTotalResisted] = useState(24500);

  const numericPrice = parseFloat(itemPrice) || 0;
  const daysBurned = safeDailyLimit > 0 ? (numericPrice / safeDailyLimit).toFixed(1) : 0;

  const handleLockItem = (e) => {
    e.preventDefault();
    if (!itemName || !numericPrice) return;

    const newItem = {
      id: `cool-${Date.now()}`,
      name: itemName,
      price: numericPrice,
      lockedAt: new Date().toISOString(),
      hoursRemaining: 24,
      daysOfDailyAllowance: daysBurned
    };

    setCoolingItems([newItem, ...coolingItems]);
    setItemName('');
    setItemPrice('');
    sounds.playWarning();
    if (onAddToast) onAddToast(`Locked "${newItem.name}" into 24-hr Cooling Off Vault`, 'warning');
  };

  const handleResist = (item) => {
    setCoolingItems(coolingItems.filter(i => i.id !== item.id));
    setTotalResisted(prev => prev + item.price);
    sounds.playSuccess();
    confetti({
      particleCount: 70,
      spread: 60,
      origin: { y: 0.6 }
    });
    if (onAddToast) onAddToast(`🎉 Impulse defeated! Saved ${formatINR(item.price)} from regret!`, 'success');
  };

  const handleBuyAnyway = (item) => {
    setCoolingItems(coolingItems.filter(i => i.id !== item.id));
    if (onLogExpense) {
      onLogExpense({
        id: `tx-${Date.now()}`,
        title: item.name,
        amount: item.price,
        type: 'expense',
        category: 'Shopping & Gadgets',
        tag: 'wants',
        mode: 'salaried',
        payment_method: 'Credit Card',
        date: new Date().toISOString().split('T')[0],
        is_recurring: false
      });
    }
    sounds.playWarning();
    if (onAddToast) onAddToast(`Logged ${item.name} as Want expense`, 'info');
  };

  return (
    <motion.div 
      whileHover={{ y: -2 }}
      className="glass-card p-6 sm:p-7 my-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3 mb-5">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-rose-500/15 border border-rose-500/35 text-rose-400 flex items-center justify-center shrink-0">
            <Lock size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h3 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
                Impulse Purchase Regret Predictor & 24h Cooling Vault
              </h3>
              <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider bg-rose-500/15 text-rose-400 border border-rose-500/30">
                BEHAVIORAL SHIELD
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Prevents impulse spikes by testing if you still crave it after 24 hours
            </p>
          </div>
        </div>

        {/* Resisted Counter Pill */}
        <div className="px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/25 flex items-center gap-2">
          <Gift size={15} className="text-emerald-400" />
          <span className="text-xs text-emerald-400 font-semibold">
            Total Regret Saved: <strong className="font-mono">{formatINR(totalResisted)}</strong>
          </span>
        </div>
      </div>

      {/* Input Simulator Form */}
      <form onSubmit={handleLockItem} className="p-5 rounded-2xl bg-black/40 border border-white/[0.08] mb-5">
        <div className="text-xs font-bold text-white mb-3 uppercase tracking-wider">
          Test an Impulse Item Before Buying
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div>
            <label className="text-xs text-slate-300 block mb-1">
              What do you feel like buying right now?
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Smartwatch, Zara Jacket, Mechanical Keyboard"
              value={itemName}
              onChange={(e) => setItemName(e.target.value)}
              className="fintech-input"
            />
          </div>

          <div>
            <label className="text-xs text-slate-300 block mb-1">
              Item Price (₹)
            </label>
            <input
              type="number"
              step="any"
              required
              placeholder="e.g. 6500"
              value={itemPrice}
              onChange={(e) => setItemPrice(e.target.value)}
              className="fintech-input"
            />
          </div>
        </div>

        {/* Quick Sample Presets */}
        <div className="flex gap-1.5 mt-2.5 flex-wrap items-center">
          <span className="text-[11px] text-slate-500 font-medium">Quick Test:</span>
          {[
            { name: 'Apple Watch Series 10', price: 44900 },
            { name: 'Zara Leather Boots', price: 6990 },
            { name: 'Sony WH-1000XM5', price: 18990 },
            { name: 'Gourmet Weekend Dinner', price: 4800 }
          ].map(preset => (
            <button
              key={preset.name}
              type="button"
              onClick={() => {
                setItemName(preset.name);
                setItemPrice(preset.price);
              }}
              className="text-[11px] px-2.5 py-0.5 rounded-full bg-white/[0.04] border border-white/[0.08] text-cyan-300 hover:bg-white/[0.08] cursor-pointer"
            >
              {preset.name} ({formatINR(preset.price)})
            </button>
          ))}
        </div>

        {/* Real-Time Impact Warning */}
        {numericPrice > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            className={`mt-3.5 p-3.5 rounded-xl border flex items-center justify-between flex-wrap gap-2.5 ${
              numericPrice > (safeDailyLimit * 5) 
                ? 'bg-rose-500/10 border-rose-500/30' 
                : 'bg-amber-500/10 border-amber-500/30'
            }`}
          >
            <div>
              <div className={`text-xs font-bold ${numericPrice > (safeDailyLimit * 5) ? 'text-rose-400' : 'text-amber-400'}`}>
                🚨 PREDICTED PAYDAY DAMAGE:
              </div>
              <div className="text-xs text-white mt-0.5">
                Buying this burns <strong className="font-mono text-rose-400 font-bold">{daysBurned} Days</strong> of your safe daily allowance!
              </div>
            </div>

            <motion.button
              whileTap={{ scale: 0.95 }}
              type="submit"
              className="btn-fintech-secondary text-xs !bg-rose-500/20 text-rose-300 !border-rose-500/35 hover:!bg-rose-500/30"
            >
              <Lock size={13} />
              <span>Lock in 24h Vault Instead</span>
            </motion.button>
          </motion.div>
        )}
      </form>

      {/* Cooling Vault Items List */}
      <div>
        <div className="text-xs font-bold text-white mb-2.5 flex items-center gap-1.5 uppercase tracking-wider">
          <Clock size={14} className="text-cyan-400" />
          <span>Active 24-Hour Cooling Off Locks ({coolingItems.length})</span>
        </div>

        <div className="flex flex-col gap-2.5">
          {coolingItems.length === 0 ? (
            <div className="py-6 text-center text-slate-400 text-xs">
              No items currently locked in vault. All cravings neutralized!
            </div>
          ) : (
            coolingItems.map(item => (
              <div
                key={item.id}
                className="flex items-center justify-between p-3.5 sm:p-4 rounded-2xl bg-black/35 border border-white/[0.08] flex-wrap gap-3"
              >
                <div>
                  <div className="text-sm font-bold text-white">
                    {item.name}
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    Equivalent to <strong className="text-rose-400">{item.daysOfDailyAllowance} days</strong> of survival spend • ⏳ {item.hoursRemaining} hours left in lock
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="font-mono text-base font-extrabold text-white">
                    {formatINR(item.price)}
                  </div>

                  <div className="flex gap-2">
                    <motion.button
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleResist(item)}
                      className="btn-fintech-primary text-xs !py-1 !px-2.5 rounded-full"
                    >
                      <CheckCircle2 size={13} />
                      <span>I Defeated It!</span>
                    </motion.button>

                    <motion.button
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleBuyAnyway(item)}
                      className="btn-fintech-secondary text-xs !py-1 !px-2.5 rounded-full"
                    >
                      <span>Still Need It</span>
                    </motion.button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </motion.div>
  );
}
