import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Code2, Copy, Check, Terminal } from 'lucide-react';
import { SQL_SCHEMA } from '../lib/defaultData';

export function SqlSchemaModal({ isOpen, onClose }) {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(SQL_SCHEMA);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.94, y: 16 }}
        transition={{ type: 'spring', damping: 25, stiffness: 350 }}
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-2xl p-6 sm:p-8 rounded-3xl glass-card-elevated border border-white/10 shadow-2xl flex flex-col max-h-[88vh]"
      >
        {/* Glow */}
        <div className="absolute top-0 right-1/4 w-48 h-24 bg-fintech-neon-purple/15 blur-3xl pointer-events-none rounded-full" />

        {/* Header */}
        <div className="flex items-center justify-between mb-5 relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/10 border border-cyan-500/25 flex items-center justify-center text-cyan-400 shadow-glow-cyan">
              <Code2 size={20} />
            </div>
            <div>
              <h3 className="text-xl font-bold tracking-tight text-white">Supabase SQL Schema</h3>
              <p className="text-xs text-slate-400">Copy & run in your Supabase SQL Editor to provision tables</p>
            </div>
          </div>

          <motion.button
            whileHover={{ scale: 1.1, rotate: 90 }}
            whileTap={{ scale: 0.9 }}
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <X size={18} />
          </motion.button>
        </div>

        {/* Instructions banner */}
        <div className="bg-cyan-500/10 border border-cyan-500/20 rounded-xl p-3.5 mb-4 text-xs text-cyan-200 flex items-center gap-2.5">
          <Terminal size={16} className="text-cyan-400 shrink-0" />
          <span>Go to: Supabase Dashboard &gt; <strong>SQL Editor</strong> &gt; <strong>New Query</strong> &gt; Paste & click <strong>RUN</strong>.</span>
        </div>

        {/* Code box */}
        <div className="flex-1 overflow-y-auto bg-slate-950/90 border border-white/10 rounded-xl p-4 font-mono text-xs text-indigo-200/90 leading-relaxed whitespace-pre mb-5 selection:bg-cyan-500/30">
          {SQL_SCHEMA}
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-transparent hover:bg-white/5 text-slate-400 hover:text-white text-xs font-medium transition-all"
          >
            Close
          </button>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleCopy}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-400 text-slate-950 font-bold text-xs shadow-glow-emerald flex items-center gap-2 hover:brightness-110 transition-all"
          >
            {copied ? <Check size={16} className="text-slate-950" /> : <Copy size={16} />}
            <span>{copied ? 'Copied to Clipboard!' : 'Copy SQL Script'}</span>
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
}
