import React from 'react';
import { motion } from 'framer-motion';
import { 
  Wallet, 
  ArrowUpRight, 
  ArrowDownRight, 
  PiggyBank, 
  Clock
} from 'lucide-react';
import { formatINR } from '../lib/formatters';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.08
    }
  }
};

const cardVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: { 
    opacity: 1, 
    y: 0, 
    transition: { type: 'spring', stiffness: 350, damping: 25 } 
  }
};

export function MetricCards({ 
  mode, 
  settings, 
  transactions, 
  onQuickAdd 
}) {
  const totalIncome = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + Number(t.amount), 0);

  const totalExpense = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + Number(t.amount), 0);

  const wantsExpense = transactions
    .filter(t => t.type === 'expense' && (t.tag === 'wants' || t.tag === 'client_payout'))
    .reduce((sum, t) => sum + Number(t.amount), 0);

  const wantsRatio = totalExpense > 0 ? Math.round((wantsExpense / totalExpense) * 100) : 0;
  const netSavings = totalIncome - totalExpense;
  const savingsRate = totalIncome > 0 ? Math.round((netSavings / totalIncome) * 100) : 0;

  const monthlyBurn = totalExpense || 1;
  const runwayMonths = (Number(settings.available_balance) / monthlyBurn).toFixed(1);

  const cards = [
    {
      title: 'Total Available Balance',
      value: formatINR(settings.available_balance),
      subtitle: `Liquid funds in primary ${mode === 'salaried' ? 'salary' : 'current'} account`,
      icon: Wallet,
      color: '#00F5A0',
      badgeClass: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
      badge: 'LIQUID',
      glow: 'from-emerald-500/10 to-transparent'
    },
    {
      title: mode === 'salaried' ? 'Total Income This Month' : 'Total Revenue & Retainers',
      value: formatINR(totalIncome),
      subtitle: `${transactions.filter(t => t.type === 'income').length} Credits Recorded`,
      icon: ArrowUpRight,
      color: '#00D8F6',
      badgeClass: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
      badge: 'INFLOW',
      glow: 'from-cyan-500/10 to-transparent'
    },
    {
      title: mode === 'salaried' ? 'Monthly Expenses' : 'Operational Spend (OPEX)',
      value: formatINR(totalExpense),
      subtitle: `${wantsRatio}% spent on optional/wants`,
      icon: ArrowDownRight,
      color: '#FF4757',
      badgeClass: wantsRatio > 35 ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' : 'bg-rose-500/10 text-rose-400 border-rose-500/30',
      badge: `${wantsRatio}% WANTS`,
      glow: 'from-rose-500/10 to-transparent'
    },
    {
      title: mode === 'salaried' ? 'Net Savings Rate' : 'Cash Runway Engine',
      value: mode === 'salaried' ? `${savingsRate}%` : `${runwayMonths} Mo`,
      subtitle: mode === 'salaried' 
        ? `${formatINR(netSavings)} retained this month` 
        : `Runway based on current burn rate`,
      icon: mode === 'salaried' ? PiggyBank : Clock,
      color: '#8B5CF6',
      badgeClass: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
      badge: mode === 'salaried' ? 'SAVINGS' : 'RUNWAY',
      glow: 'from-purple-500/10 to-transparent'
    }
  ];

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 my-6"
    >
      {cards.map((card) => {
        const IconComponent = card.icon;
        return (
          <motion.div
            key={card.title}
            variants={cardVariants}
            whileHover={{ y: -4, scale: 1.01 }}
            className="glass-card relative overflow-hidden p-5 sm:p-6 group cursor-default"
          >
            {/* Ambient Background Gradient Corner */}
            <div className={`absolute top-0 right-0 w-36 h-36 bg-gradient-to-bl ${card.glow} opacity-40 blur-2xl group-hover:opacity-70 transition-opacity pointer-events-none`} />

            <div className="flex items-center justify-between mb-3 relative z-10">
              <span className="text-xs font-semibold text-slate-400 tracking-wide">
                {card.title}
              </span>
              <div className="w-9 h-9 rounded-xl bg-white/[0.04] border border-white/[0.08] flex items-center justify-center transition-transform group-hover:scale-110">
                <IconComponent size={17} style={{ color: card.color }} />
              </div>
            </div>

            <div className="font-mono text-2xl sm:text-3xl font-extrabold text-white tracking-tight mb-2 relative z-10">
              {card.value}
            </div>

            <div className="flex items-center justify-between text-xs text-slate-400 relative z-10 mt-auto pt-2 border-t border-white/[0.04]">
              <span className="truncate pr-2">{card.subtitle}</span>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase shrink-0 ${card.badgeClass}`}>
                {card.badge}
              </span>
            </div>
          </motion.div>
        );
      })}
    </motion.div>
  );
}
