import React, { createContext, useContext, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, AlertTriangle, AlertCircle, Info, X } from 'lucide-react';

const ToastContext = createContext();

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);

  const addToast = useCallback((message, type = 'success', duration = 3500) => {
    const id = Date.now() + Math.random().toString(36).substring(2, 9);
    setToasts(prev => [...prev, { id, message, type }]);

    if (duration > 0) {
      setTimeout(() => {
        removeToast(id);
      }, duration);
    }
  }, []);

  const removeToast = useCallback((id) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  return (
    <ToastContext.Provider value={{ addToast }}>
      {children}
      {/* Toast Render Container */}
      <div style={{
        position: 'fixed',
        bottom: 24,
        right: 24,
        zIndex: 9999,
        display: 'flex',
        flexDirection: 'column',
        gap: 10,
        pointerEvents: 'none'
      }}>
        <AnimatePresence>
          {toasts.map(toast => {
            const isSuccess = toast.type === 'success';
            const isWarning = toast.type === 'warning';
            const isError = toast.type === 'error';

            const borderColor = isSuccess 
              ? 'rgba(0, 245, 160, 0.4)' 
              : isWarning 
              ? 'rgba(255, 184, 0, 0.4)' 
              : 'rgba(255, 71, 87, 0.4)';

            const glowShadow = isSuccess
              ? '0 8px 24px rgba(0, 245, 160, 0.25)'
              : isWarning
              ? '0 8px 24px rgba(255, 184, 0, 0.25)'
              : '0 8px 24px rgba(255, 71, 87, 0.25)';

            return (
              <motion.div
                key={toast.id}
                initial={{ opacity: 0, y: 20, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 15, scale: 0.9 }}
                transition={{ duration: 0.2 }}
                style={{
                  pointerEvents: 'auto',
                  minWidth: 280,
                  maxWidth: 420,
                  background: 'rgba(14, 18, 28, 0.95)',
                  backdropFilter: 'blur(16px)',
                  border: `1px solid ${borderColor}`,
                  borderRadius: 'var(--radius-md)',
                  boxShadow: glowShadow,
                  padding: '12px 16px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: 12,
                  color: '#FFFFFF'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  {isSuccess && <CheckCircle2 size={18} color="var(--accent-emerald)" />}
                  {isWarning && <AlertTriangle size={18} color="var(--accent-amber)" />}
                  {isError && <AlertCircle size={18} color="var(--accent-coral)" />}
                  {toast.type === 'info' && <Info size={18} color="var(--accent-cyan)" />}
                  <span style={{ fontSize: '0.84rem', fontWeight: 600 }}>
                    {toast.message}
                  </span>
                </div>

                <button
                  onClick={() => removeToast(toast.id)}
                  style={{
                    background: 'transparent',
                    border: 'none',
                    color: 'var(--text-muted)',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    padding: 2
                  }}
                >
                  <X size={15} />
                </button>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within ToastProvider');
  }
  return context;
}
