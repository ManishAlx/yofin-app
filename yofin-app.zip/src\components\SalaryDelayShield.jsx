import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  LifeBuoy
} from 'lucide-react';
import { formatINR } from '../lib/formatters';
import { sounds } from '../lib/soundEffects';

export function SalaryDelayShield({ 
  mode, 
  settings, 
  onAddToast 
}) {
  const [isActive, setIsActive] = useState(false);
  const [delayDays, setDelayDays] = useState(5);

  const toggleShield = () => {
    const nextState = !isActive;
    setIsActive(nextState);
    if (nextState) {
      sounds.playWarning();
      if (onAddToast) onAddToast(`🚨 SOS Salary Delay Shield ACTIVATED (+${delayDays} days)`, 'warning');
    } else {
      sounds.playSuccess();
      if (onAddToast) onAddToast('Salary Delay Shield deactivated. Normal mode restored.', 'success');
    }
  };

  const dailyMinimalRation = mode === 'salaried' ? 350 : 1200;
  const recommendedVaultDraw = dailyMinimalRation * delayDays;

  return (
    <motion.div 
      whileHover={{ y: -2 }}
      className={`glass-card p-6 sm:p-7 my-6 transition-all duration-300 ${
        isActive ? 'border-rose-500/50 shadow-glow-coral' : 'border-white/[0.08]'
      }`}
    >
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3 mb-4">
        <div className="flex items-center gap-3.5">
          <div className={`w-11 h-11 rounded-xl flex items-center justify-center border ${
            isActive 
              ? 'bg-rose-500/20 border-rose-500/40 text-rose-400' 
              : 'bg-amber-500/15 border-amber-500/35 text-amber-400'
          }`}>
            <LifeBuoy size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h3 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
                Salary Delay SOS Shield Protocol
              </h3>
              <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider ${
                isActive 
                  ? 'bg-rose-500/15 text-rose-400 border border-rose-500/30' 
                  : 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
              }`}>
                {isActive ? 'SHIELD ENGAGED' : 'STANDBY'}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Emergency defense protocol when salary or client invoice settlement is delayed
            </p>
          </div>
        </div>

        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={toggleShield}
          className={`text-xs px-4 py-2 rounded-full font-bold transition-all cursor-pointer ${
            isActive 
              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30' 
              : 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
          }`}
        >
          {isActive ? 'Deactivate SOS Shield' : 'Activate SOS Shield'}
        </motion.button>
      </div>

      {/* Main Content */}
      <AnimatePresence>
        {isActive ? (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="flex flex-col gap-4 mt-4 pt-4 border-t border-white/[0.06]"
          >
            {/* Delay Selector */}
            <div className="p-3.5 sm:p-4 rounded-xl bg-rose-500/[0.08] border border-rose-500/25 flex items-center justify-between flex-wrap gap-3">
              <div>
                <span className="text-xs font-bold text-white block">
                  Expected Payment Delay Duration:
                </span>
                <span className="text-[11px] text-slate-400">
                  Recalculates rations so you never need instant high-interest payday loans
                </span>
              </div>

              <div className="flex gap-2">
                {[3, 5, 7, 10].map(d => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setDelayDays(d)}
                    className={`px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${
                      delayDays === d 
                        ? 'bg-rose-500 text-white shadow-sm' 
                        : 'bg-black/40 text-slate-400 border border-white/[0.08] hover:text-white'
                    }`}
                  >
                    +{d} Days Delay
                  </button>
                ))}
              </div>
            </div>

            {/* Protocol Action Checklist */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 sm:p-5 rounded-2xl bg-black/40 border border-white/[0.08]">
                <div className="text-[11px] font-bold text-rose-400 uppercase tracking-wider">
                  RULE 1: SURVIVAL RATION CAP
                </div>
                <div className="font-mono text-2xl font-extrabold text-white mt-1">
                  {formatINR(dailyMinimalRation)} <span className="text-xs font-semibold text-slate-400 font-sans">/ day</span>
                </div>
                <div className="text-xs text-slate-400 mt-1">
                  Discretionary ordering frozen. Strictly essentials only (milk, groceries, commute).
                </div>
              </div>

              <div className="p-4 sm:p-5 rounded-2xl bg-black/40 border border-white/[0.08]">
                <div className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider">
                  RULE 2: RECOMMENDED SAFE VAULT DRAW
                </div>
                <div className="font-mono text-2xl font-extrabold text-cyan-400 mt-1">
                  {formatINR(recommendedVaultDraw)}
                </div>
                <div className="text-xs text-slate-400 mt-1">
                  Draw exactly this amount from your Emergency Vault. Avoid any credit card EMI loans!
                </div>
              </div>

              <div className="p-4 sm:p-5 rounded-2xl bg-black/40 border border-white/[0.08]">
                <div className="text-[11px] font-bold text-amber-400 uppercase tracking-wider">
                  RULE 3: SAFE TO PAUSE FOR {delayDays} DAYS
                </div>
                <div className="text-xs text-slate-300 mt-2 flex flex-col gap-1.5 font-medium">
                  <div>• Pause weekly mutual fund SIPs</div>
                  <div>• Snooze Netflix & Cult.fit renewal</div>
                  <div>• Cook pantry reserves; 0 delivery</div>
                </div>
              </div>
            </div>
          </motion.div>
        ) : (
          <div className="text-xs text-slate-400 leading-relaxed">
            Standing by. If HR or your employer delays salary processing or your client delays milestone approval, click <strong>"Activate SOS Shield"</strong> above to immediately generate an emergency ration plan.
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
