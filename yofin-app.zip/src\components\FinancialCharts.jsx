import React, { useState } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  PointElement,
  LineElement
} from 'chart.js';
import { Bar, Doughnut } from 'react-chartjs-2';
import { BarChart3, PieChart, Activity } from 'lucide-react';
import { motion } from 'framer-motion';
import { formatINR } from '../lib/formatters';

// Register ChartJS plugins
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  PointElement,
  LineElement
);

export function FinancialCharts({ transactions, mode, safeDailyLimit = 1200 }) {
  const [activeTab, setActiveTab] = useState('category'); // 'category' | 'monthly' | 'daily'

  const categoryMap = {};
  transactions
    .filter(t => t.type === 'expense')
    .forEach(t => {
      categoryMap[t.category] = (categoryMap[t.category] || 0) + Number(t.amount);
    });

  const categoryLabels = Object.keys(categoryMap);
  const categoryValues = Object.values(categoryMap);

  const neonColors = [
    '#00F5A0',
    '#00D8F6',
    '#8B5CF6',
    '#FFB800',
    '#FF4757',
    '#EC4899',
    '#10B981',
    '#6366F1'
  ];

  const doughnutData = {
    labels: categoryLabels.length > 0 ? categoryLabels : ['No Expenses Recorded'],
    datasets: [
      {
        data: categoryValues.length > 0 ? categoryValues : [1],
        backgroundColor: categoryValues.length > 0 ? categoryLabels.map((_, i) => neonColors[i % neonColors.length]) : ['#222736'],
        borderColor: '#0D0F17',
        borderWidth: 4,
        hoverOffset: 6
      }
    ]
  };

  const doughnutOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'right',
        labels: {
          color: '#94A3B8',
          font: { family: 'Plus Jakarta Sans', size: 12 },
          boxWidth: 14,
          padding: 14
        }
      },
      tooltip: {
        backgroundColor: 'rgba(13, 15, 23, 0.95)',
        titleColor: '#FFFFFF',
        bodyColor: '#00F5A0',
        borderColor: 'rgba(255, 255, 255, 0.1)',
        borderWidth: 1,
        padding: 12,
        callbacks: {
          label: (context) => ` ${context.label}: ${formatINR(context.parsed)}`
        }
      }
    },
    cutout: '72%'
  };

  const monthlyData = {
    labels: ['Jun', 'Jul', 'Aug', 'Sep', 'Oct'],
    datasets: [
      {
        label: 'Income (Inflow)',
        data: mode === 'salaried' ? [85000, 85000, 90000, 95000, 120000] : [210000, 240000, 290000, 310000, 300000],
        backgroundColor: 'rgba(0, 245, 160, 0.85)',
        borderRadius: 8
      },
      {
        label: 'Expenses (Outflow)',
        data: mode === 'salaried' ? [48000, 52000, 59000, 46000, 48090] : [92000, 110000, 135000, 120000, 100300],
        backgroundColor: 'rgba(255, 71, 87, 0.85)',
        borderRadius: 8
      }
    ]
  };

  const monthlyOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
        labels: {
          color: '#94A3B8',
          font: { family: 'Plus Jakarta Sans', size: 12 }
        }
      },
      tooltip: {
        backgroundColor: 'rgba(13, 15, 23, 0.95)',
        titleColor: '#FFFFFF',
        borderColor: 'rgba(255, 255, 255, 0.1)',
        borderWidth: 1,
        callbacks: {
          label: (context) => ` ${context.dataset.label}: ${formatINR(context.parsed.y)}`
        }
      }
    },
    scales: {
      x: {
        grid: { color: 'rgba(255, 255, 255, 0.04)' },
        ticks: { color: '#64748B' }
      },
      y: {
        grid: { color: 'rgba(255, 255, 255, 0.04)' },
        ticks: { 
          color: '#64748B',
          callback: (val) => `₹${val / 1000}k`
        }
      }
    }
  };

  const dailyData = {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [
      {
        type: 'bar',
        label: 'Actual Daily Spend',
        data: mode === 'salaried' ? [850, 1420, 620, 2100, 950, 3200, 1120] : [3400, 8900, 2100, 14200, 4300, 1200, 800],
        backgroundColor: (context) => {
          const val = context.raw;
          return val > safeDailyLimit ? 'rgba(255, 71, 87, 0.85)' : 'rgba(0, 216, 246, 0.85)';
        },
        borderRadius: 8
      },
      {
        type: 'line',
        label: `Safe Daily Benchmark (${formatINR(safeDailyLimit)}/d)`,
        data: Array(7).fill(safeDailyLimit),
        borderColor: 'rgba(0, 245, 160, 0.9)',
        borderWidth: 2,
        borderDash: [5, 5],
        pointRadius: 0,
        fill: false
      }
    ]
  };

  const dailyOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
        labels: {
          color: '#94A3B8',
          font: { family: 'Plus Jakarta Sans', size: 12 }
        }
      },
      tooltip: {
        backgroundColor: 'rgba(13, 15, 23, 0.95)',
        callbacks: {
          label: (context) => ` ${context.dataset.label}: ${formatINR(context.parsed.y)}`
        }
      }
    },
    scales: {
      x: {
        grid: { color: 'rgba(255, 255, 255, 0.04)' },
        ticks: { color: '#64748B' }
      },
      y: {
        grid: { color: 'rgba(255, 255, 255, 0.04)' },
        ticks: { 
          color: '#64748B',
          callback: (val) => `₹${val}`
        }
      }
    }
  };

  const tabs = [
    { id: 'category', label: 'Category Breakdown', icon: PieChart, color: 'text-emerald-400' },
    { id: 'monthly', label: 'Month-over-Month', icon: BarChart3, color: 'text-cyan-400' },
    { id: 'daily', label: 'Daily Burn vs Safe Cap', icon: Activity, color: 'text-purple-400' }
  ];

  return (
    <motion.div 
      whileHover={{ y: -2 }}
      className="glass-card p-6 sm:p-7 my-6"
    >
      {/* Chart Navigation Tabs */}
      <div className="flex items-center justify-between flex-wrap gap-3 mb-6">
        <div>
          <h3 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
            Visual Financial Analytics
          </h3>
          <p className="text-xs text-slate-400">
            Track expense distributions, monthly trends, and daily limit compliance
          </p>
        </div>

        <div className="flex items-center gap-1.5 p-1 rounded-full border border-white/[0.08] bg-black/40 overflow-x-auto max-w-full">
          {tabs.map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`relative px-3.5 py-1.5 rounded-full text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 shrink-0 ${
                  isActive ? 'text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Icon size={14} className={isActive ? tab.color : 'text-slate-500'} />
                <span>{tab.label}</span>
                {isActive && (
                  <motion.div
                    layoutId="chart-tab-highlight"
                    className="absolute inset-0 rounded-full bg-white/[0.08] border border-white/[0.12] -z-10"
                    transition={{ type: 'spring', stiffness: 500, damping: 35 }}
                  />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Canvas Area */}
      <div className="h-80 w-full relative">
        {activeTab === 'category' && (
          <Doughnut data={doughnutData} options={doughnutOptions} />
        )}
        {activeTab === 'monthly' && (
          <Bar data={monthlyData} options={monthlyOptions} />
        )}
        {activeTab === 'daily' && (
          <Bar data={dailyData} options={dailyOptions} />
        )}
      </div>
    </motion.div>
  );
}
