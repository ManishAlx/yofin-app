import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, 
  Trash2, 
  Download, 
  ArrowUpRight, 
  ArrowDownRight, 
  Plus
} from 'lucide-react';
import { formatINR, formatDate } from '../lib/formatters';

const listContainerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05
    }
  }
};

const listItemVariants = {
  hidden: { opacity: 0, y: 10 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { type: 'spring', stiffness: 400, damping: 25 } 
  }
};

export function TransactionList({ 
  transactions, 
  onDeleteTransaction, 
  onOpenAddModal, 
  mode 
}) {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState('all');

  const filtered = transactions.filter((tx) => {
    const matchSearch = tx.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        tx.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        (tx.payment_method && tx.payment_method.toLowerCase().includes(searchTerm.toLowerCase()));

    if (!matchSearch) return false;

    if (activeFilter === 'all') return true;
    if (activeFilter === 'income') return tx.type === 'income';
    if (activeFilter === 'expense') return tx.type === 'expense';
    if (activeFilter === 'essential') return tx.tag === 'essential' || tx.tag === 'business_opex';
    if (activeFilter === 'wants') return tx.tag === 'wants' || tx.tag === 'client_payout';

    return true;
  });

  const exportToCSV = () => {
    const headers = ['ID', 'Date', 'Title', 'Type', 'Category', 'Tag', 'Amount (INR)', 'Payment Method', 'Recurring'];
    const rows = filtered.map(t => [
      t.id,
      t.date,
      `"${t.title.replace(/"/g, '""')}"`,
      t.type,
      t.category,
      t.tag,
      t.amount,
      t.payment_method || 'UPI',
      t.is_recurring ? 'Yes' : 'No'
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `yofin_${mode}_ledger_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="glass-card p-6 sm:p-7 my-6">
      {/* Top Bar */}
      <div className="flex items-center justify-between flex-wrap gap-4 mb-6">
        <div>
          <h3 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
            Cashflow & Transaction Ledger
          </h3>
          <p className="text-xs text-slate-400">
            Real-time categorized ledger with Essential vs Wants discretionary tagging
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={exportToCSV}
            className="btn-fintech-secondary text-xs !py-1.5 !px-3 rounded-full"
            title="Download CSV Ledger"
          >
            <Download size={13} className="text-cyan-400" />
            <span>Export CSV</span>
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={onOpenAddModal}
            className="btn-fintech-primary text-xs !py-1.5 !px-3.5 rounded-full"
          >
            <Plus size={14} />
            <span>Add Transaction</span>
          </motion.button>
        </div>
      </div>

      {/* Search Input & Filter Chips */}
      <div className="flex items-center justify-between flex-wrap gap-3 mb-5">
        {/* Search */}
        <div className="relative flex-1 min-w-[240px] max-w-sm">
          <Search
            size={15}
            className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
          />
          <input
            type="text"
            placeholder="Search payments, categories, payees..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="fintech-input !pl-9 !py-2 text-xs rounded-full"
          />
        </div>

        {/* Filter Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto max-w-full pb-1">
          {[
            { id: 'all', label: 'All Items' },
            { id: 'expense', label: 'Expenses' },
            { id: 'income', label: 'Incomes' },
            { id: 'essential', label: mode === 'salaried' ? 'Essentials Only' : 'Core OPEX' },
            { id: 'wants', label: mode === 'salaried' ? 'Wants / Leaks' : 'Contractor' }
          ].map(chip => (
            <button
              key={chip.id}
              onClick={() => setActiveFilter(chip.id)}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-all shrink-0 cursor-pointer ${
                activeFilter === chip.id 
                  ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' 
                  : 'bg-white/[0.04] text-slate-400 border border-white/[0.08] hover:text-white'
              }`}
            >
              {chip.label}
            </button>
          ))}
        </div>
      </div>

      {/* Transaction List */}
      <motion.div 
        variants={listContainerVariants}
        initial="hidden"
        animate="visible"
        className="flex flex-col gap-2.5"
      >
        <AnimatePresence>
          {filtered.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-sm">
              No transactions match your search or filter.
            </div>
          ) : (
            filtered.map((tx) => {
              const isIncome = tx.type === 'income';
              const isWants = tx.tag === 'wants' || tx.tag === 'client_payout';

              return (
                <motion.div
                  key={tx.id}
                  layout
                  variants={listItemVariants}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="flex items-center justify-between p-3.5 sm:p-4 rounded-2xl bg-black/35 border border-white/[0.06] hover:border-white/[0.14] transition-all gap-3 group"
                >
                  {/* Left: Icon & Details */}
                  <div className="flex items-center gap-3.5 min-w-0 flex-1">
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${
                      isIncome 
                        ? 'bg-emerald-500/10 border-emerald-500/25 text-emerald-400' 
                        : 'bg-rose-500/10 border-rose-500/25 text-rose-400'
                    }`}>
                      {isIncome ? (
                        <ArrowUpRight size={18} />
                      ) : (
                        <ArrowDownRight size={18} />
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-bold text-white truncate">
                        {tx.title}
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5 flex-wrap">
                        <span>{tx.category}</span>
                        <span>•</span>
                        <span>{formatDate(tx.date)}</span>
                        <span>•</span>
                        <span className="text-slate-300">
                          {tx.payment_method || 'UPI'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Middle Tag */}
                  <div className="hidden sm:block">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase ${
                      isIncome 
                        ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30' 
                        : isWants 
                        ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' 
                        : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                    }`}>
                      {isIncome ? 'INFLOW' : isWants ? 'WANTS' : 'ESSENTIAL'}
                    </span>
                  </div>

                  {/* Right: Amount & Delete */}
                  <div className="flex items-center gap-3">
                    <div className={`font-mono text-sm sm:text-base font-extrabold text-right ${
                      isIncome ? 'text-emerald-400' : 'text-white'
                    }`}>
                      {isIncome ? '+' : '-'}{formatINR(tx.amount)}
                    </div>

                    <button
                      onClick={() => onDeleteTransaction(tx.id)}
                      className="opacity-60 group-hover:opacity-100 hover:text-rose-400 text-slate-500 p-1 rounded-lg transition-all cursor-pointer"
                      title="Delete record"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </motion.div>
              );
            })
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
