import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import confetti from 'canvas-confetti';
import { 
  Flame, 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle, 
  Sliders, 
  PartyPopper, 
  Sparkles,
  Edit3,
  Check
} from 'lucide-react';
import { formatINR } from '../lib/formatters';

export function PaydaySurvivalCalculator({ 
  mode, 
  settings, 
  onUpdateSettings 
}) {
  const [isEditing, setIsEditing] = useState(false);
  const [tempBalance, setTempBalance] = useState(settings?.available_balance || 0);
  const [tempBills, setTempBills] = useState(settings?.pending_fixed_bills || 0);
  const [tempPayday, setTempPayday] = useState(settings?.payday_day || 1);

  // Sync temp edit inputs when settings prop updates
  React.useEffect(() => {
    if (settings) {
      setTempBalance(settings.available_balance || 0);
      setTempBills(settings.pending_fixed_bills || 0);
      setTempPayday(settings.payday_day || 1);
    }
  }, [settings]);

  // What-If Simulator state
  const [showSimulator, setShowSimulator] = useState(false);
  const [simulatedExpense, setSimulatedExpense] = useState(0);
  const [delayDays, setDelayDays] = useState(0);

  // Calculate days to next payday
  const today = new Date();
  const currentDay = today.getDate();
  const paydayDay = settings.payday_day || 1;

  let daysToPayday = 0;
  if (currentDay === paydayDay) {
    daysToPayday = 0;
  } else if (currentDay < paydayDay) {
    daysToPayday = paydayDay - currentDay;
  } else {
    const nextMonth = new Date(today.getFullYear(), today.getMonth() + 1, paydayDay);
    const diffTime = Math.abs(nextMonth - today);
    daysToPayday = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }

  const effectiveDays = Math.max(1, daysToPayday + Number(delayDays));
  const effectiveAvailableFunds = Math.max(0, Number(settings.available_balance) - Number(settings.pending_fixed_bills));
  const simulatedEffectiveFunds = Math.max(0, effectiveAvailableFunds - Number(simulatedExpense));

  const safeDailyLimit = Math.floor(effectiveAvailableFunds / effectiveDays);
  const simulatedDailyLimit = Math.floor(simulatedEffectiveFunds / effectiveDays);

  const thresholdRed = mode === 'salaried' ? 450 : 2500;
  const thresholdAmber = mode === 'salaried' ? 1200 : 6500;

  let status = 'safe';
  let statusText = 'Safe Zone';
  let statusColor = '#00F5A0';
  let advice = mode === 'salaried' 
    ? 'Healthy buffer. You can enjoy your weekend while staying well within salary limits.'
    : 'Runway is steady. Client retainers comfortably cover ongoing operational burns.';

  if (effectiveAvailableFunds <= 0 || safeDailyLimit < thresholdRed) {
    status = 'danger';
    statusText = 'Code Red Crunch Alert';
    statusColor = '#FF4757';
    advice = mode === 'salaried'
      ? 'CRITICAL! Available funds will run out before salary day. Freeze all non-essential ordering & shopping immediately!'
      : 'CASH CRUNCH! Receivables delayed. Freeze discretionary agency spending and defer non-critical renewals.';
  } else if (safeDailyLimit < thresholdAmber) {
    status = 'amber';
    statusText = 'Amber Burn Warning';
    statusColor = '#FFB800';
    advice = mode === 'salaried'
      ? 'Caution advised. Daily allowance is tight. Cook at home and avoid impulse quick-commerce orders.'
      : 'Moderate buffer. Monitor team expense reimbursements closely until next milestone payment clears.';
  }

  const triggerConfetti = () => {
    confetti({
      particleCount: 90,
      spread: 75,
      origin: { y: 0.6 },
      colors: ['#00F5A0', '#00D8F6', '#8B5CF6', '#FFB800']
    });
  };

  const handleSaveSettings = (e) => {
    e.preventDefault();
    onUpdateSettings({
      ...settings,
      available_balance: Number(tempBalance),
      pending_fixed_bills: Number(tempBills),
      payday_day: Number(tempPayday)
    });
    setIsEditing(false);
  };

  return (
    <motion.div
      whileHover={{ y: -2 }}
      className={`glass-card p-6 sm:p-7 relative overflow-hidden transition-all duration-300 ${
        status === 'danger' ? 'border-rose-500/40 shadow-glow-coral' : status === 'amber' ? 'border-amber-500/40 shadow-glow-amber' : 'border-emerald-500/40 shadow-glow-emerald'
      }`}
    >
      {/* Background Ambient Radial Glow */}
      <div 
        className="absolute -top-20 -right-20 w-72 h-72 rounded-full blur-3xl opacity-20 pointer-events-none transition-colors duration-500"
        style={{ backgroundColor: statusColor }}
      />

      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3 mb-6 relative z-10">
        <div className="flex items-center gap-3.5">
          <div 
            className="w-11 h-11 rounded-xl flex items-center justify-center border transition-colors duration-300"
            style={{ 
              backgroundColor: `${statusColor}18`, 
              borderColor: `${statusColor}40` 
            }}
          >
            <Flame size={24} style={{ color: statusColor }} />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h2 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
                Payday Survival & Daily Burn Engine
              </h2>
              <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border uppercase tracking-wider ${
                status === 'danger' ? 'bg-rose-500/10 text-rose-400 border-rose-500/30' : status === 'amber' ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
              }`}>
                {statusText}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Live survivability quotient calculated against pending fixed commitments
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowSimulator(!showSimulator)}
            className="btn-fintech-secondary text-xs !py-1.5 !px-3 rounded-full"
          >
            <Sliders size={13} className="text-cyan-400" />
            <span>{showSimulator ? 'Close Simulator' : 'What-If Simulator'}</span>
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => {
              setTempBalance(settings.available_balance);
              setTempBills(settings.pending_fixed_bills);
              setTempPayday(settings.payday_day || 1);
              setIsEditing(!isEditing);
            }}
            className="btn-fintech-secondary text-xs !py-1.5 !px-3 rounded-full"
          >
            <Edit3 size={13} />
            <span>{isEditing ? 'Cancel' : 'Edit Base Funds'}</span>
          </motion.button>
        </div>
      </div>

      {/* Main KPI Spotlight Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-5 relative z-10">
        {/* SAFE DAILY LIMIT (HERO NUMBER) */}
        <div className="p-5 rounded-2xl bg-black/40 border border-white/[0.08] relative overflow-hidden group">
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
            Safe Daily Spend Limit
          </div>
          <div className="font-mono text-3xl sm:text-4xl font-extrabold mt-1.5 flex items-baseline gap-2" style={{ color: statusColor }}>
            {formatINR(safeDailyLimit)}
            <span className="text-xs font-semibold text-slate-400">/ day</span>
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Spend under this to never run out of salary
          </div>
        </div>

        {/* DAYS TO PAYDAY */}
        <div className="p-5 rounded-2xl bg-black/40 border border-white/[0.08]">
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
            {mode === 'salaried' ? 'Days to Salary Day' : 'Days to Invoicing / Settlement'}
          </div>
          <div className="font-mono text-3xl sm:text-4xl font-extrabold text-white mt-1.5">
            {daysToPayday === 0 ? 'TODAY! 🎉' : `${daysToPayday} Days`}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Cycle Date: {paydayDay}th of each month
          </div>
        </div>

        {/* EFFECTIVE SURPLUS FUNDS */}
        <div className="p-5 rounded-2xl bg-black/40 border border-white/[0.08]">
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
            Effective Free Buffer
          </div>
          <div className="font-mono text-3xl sm:text-4xl font-extrabold text-cyan-400 mt-1.5">
            {formatINR(effectiveAvailableFunds)}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            After {formatINR(settings.pending_fixed_bills)} fixed commitments
          </div>
        </div>
      </div>

      {/* Visual Car Fuel Tank Meter */}
      <div className="p-4 sm:p-5 rounded-2xl bg-black/35 border border-white/[0.06] mb-5 relative z-10">
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-white">
              ⛽ Payday Fuel Tank Meter
            </span>
            <span className="text-xs text-slate-400">
              ({effectiveDays} days to refill)
            </span>
          </div>
          <div className="font-mono text-xs font-bold" style={{ color: statusColor }}>
            {status === 'safe' ? 'Full Tank (Reserve OK)' : status === 'amber' ? 'Reserve Fuel Alert' : 'Fuel Tank Empty!'}
          </div>
        </div>

        {/* Segmented Fuel Bar */}
        <div className="h-3.5 bg-white/[0.04] rounded-full p-0.5 flex gap-1 border border-white/[0.06] overflow-hidden">
          {[...Array(10)].map((_, i) => {
            const fillRatio = status === 'danger' ? 0.15 : status === 'amber' ? 0.45 : 0.9;
            const isFilled = (i + 1) / 10 <= fillRatio;

            return (
              <motion.div
                key={i}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: i * 0.03 }}
                className="flex-1 rounded-sm transition-all duration-300"
                style={{
                  backgroundColor: isFilled ? statusColor : 'transparent',
                  boxShadow: isFilled ? `0 0 8px ${statusColor}` : 'none'
                }}
              />
            );
          })}
        </div>

        <div className="flex justify-between text-[11px] text-slate-500 font-mono mt-2">
          <span>E (Empty)</span>
          <span>¼ Tank</span>
          <span>½ Tank</span>
          <span>¾ Tank</span>
          <span>F (Full Buffer)</span>
        </div>
      </div>

      {/* Status Advisory Banner */}
      <div 
        className="p-3.5 sm:p-4 rounded-xl border flex items-center justify-between flex-wrap gap-3 relative z-10"
        style={{ 
          backgroundColor: `${statusColor}12`, 
          borderColor: `${statusColor}35` 
        }}
      >
        <div className="flex items-center gap-2.5">
          {status === 'safe' ? (
            <ShieldCheck size={20} style={{ color: statusColor }} />
          ) : status === 'amber' ? (
            <AlertTriangle size={20} style={{ color: statusColor }} />
          ) : (
            <ShieldAlert size={20} style={{ color: statusColor }} />
          )}
          <span className="text-xs sm:text-sm text-white font-medium">
            {advice}
          </span>
        </div>

        {daysToPayday === 0 && (
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={triggerConfetti}
            className="btn-fintech-primary text-xs !py-1.5 !px-3"
          >
            <PartyPopper size={14} />
            <span>Celebrate Salary! 🎉</span>
          </motion.button>
        )}
      </div>

      {/* WHAT-IF SIMULATOR DRAWER */}
      <AnimatePresence>
        {showSimulator && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25 }}
            className="mt-4 p-5 rounded-2xl bg-[#101420]/95 border border-cyan-500/30 relative z-10"
          >
            <div className="flex items-center gap-2 mb-4">
              <Sparkles size={16} className="text-cyan-400" />
              <h4 className="text-sm font-bold text-white">
                Stress Test / What-If Scenario Simulator
              </h4>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-slate-300 block mb-2 font-medium">
                  Simulate Planned Impulse Purchase: <strong className="text-rose-400">{formatINR(simulatedExpense)}</strong>
                </label>
                <input
                  type="range"
                  min="0"
                  max={Math.min(50000, effectiveAvailableFunds)}
                  step="500"
                  value={simulatedExpense}
                  onChange={(e) => setSimulatedExpense(Number(e.target.value))}
                  className="w-full accent-rose-500 cursor-pointer"
                />
              </div>

              <div>
                <label className="text-xs text-slate-300 block mb-2 font-medium">
                  Simulate Salary/Invoice Delay: <strong className="text-amber-400">+{delayDays} Days</strong>
                </label>
                <input
                  type="range"
                  min="0"
                  max="15"
                  step="1"
                  value={delayDays}
                  onChange={(e) => setDelayDays(Number(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>
            </div>

            <div className="mt-4 p-3 rounded-xl bg-black/40 border border-white/[0.08] flex items-center justify-between text-xs flex-wrap gap-2">
              <div>
                New Simulated Daily Cap:{' '}
                <strong className={`font-mono text-sm ml-1 ${simulatedDailyLimit < thresholdRed ? 'text-rose-400' : 'text-cyan-400'}`}>
                  {formatINR(simulatedDailyLimit)}/day
                </strong>
                <span className="text-slate-400 ml-2">
                  (Drop of {formatINR(safeDailyLimit - simulatedDailyLimit)})
                </span>
              </div>
              <button
                onClick={() => {
                  setSimulatedExpense(0);
                  setDelayDays(0);
                }}
                className="btn-fintech-secondary text-xs !py-1 !px-2.5"
              >
                Reset
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* EDIT BASE FUNDS DRAWER */}
      <AnimatePresence>
        {isEditing && (
          <motion.form
            onSubmit={handleSaveSettings}
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25 }}
            className="mt-4 p-5 rounded-2xl bg-[#101420]/95 border border-emerald-500/30 relative z-10"
          >
            <div className="text-sm font-bold text-white mb-3">
              Adjust Available Balance & Fixed Commitments
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-xs text-slate-300 block mb-1">
                  Current Available Balance (₹)
                </label>
                <input
                  type="number"
                  required
                  value={tempBalance}
                  onChange={(e) => setTempBalance(e.target.value)}
                  className="fintech-input"
                />
              </div>

              <div>
                <label className="text-xs text-slate-300 block mb-1">
                  Pending Fixed Bills (EMIs, Rent)
                </label>
                <input
                  type="number"
                  required
                  value={tempBills}
                  onChange={(e) => setTempBills(e.target.value)}
                  className="fintech-input"
                />
              </div>

              <div>
                <label className="text-xs text-slate-300 block mb-1">
                  Payday Day of Month (1-31)
                </label>
                <input
                  type="number"
                  min="1"
                  max="31"
                  required
                  value={tempPayday}
                  onChange={(e) => setTempPayday(e.target.value)}
                  className="fintech-input"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2.5 mt-4">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="btn-fintech-secondary text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn-fintech-primary text-xs"
              >
                <Check size={14} />
                <span>Save Calculation Engine</span>
              </button>
            </div>
          </motion.form>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
