// Automated Test Suite for Yofin Core Engines
import { formatINR, formatCompactINR, formatDate, formatTimeAgo } from '../src/lib/formatters.js';
import { parseBankSMS } from '../src/lib/smsParser.js';

console.log('🧪 Starting Yofin Comprehensive Function Test Suite...\n');

let passed = 0;
let failed = 0;

function assert(condition, message) {
  if (condition) {
    console.log(`  ✅ PASS: ${message}`);
    passed++;
  } else {
    console.error(`  ❌ FAIL: ${message}`);
    failed++;
  }
}

// 1. Formatters
console.log('--- 1. Testing Formatters ---');
assert(formatINR(124500) === '₹1,24,500', 'formatINR formats standard Indian currency');
assert(formatINR(0) === '₹0', 'formatINR handles 0 correctly');
assert(formatINR(-500) === '-₹500', 'formatINR handles negative numbers');
assert(formatINR(null) === '₹0', 'formatINR handles null safely');
assert(formatINR(undefined) === '₹0', 'formatINR handles undefined safely');
assert(formatINR('abc') === '₹0', 'formatINR handles NaN safely');

assert(formatCompactINR(150000) === '₹1.5L', 'formatCompactINR formats Lakhs (1.5L)');
assert(formatCompactINR(15000000) === '₹1.5Cr', 'formatCompactINR formats Crores (1.5Cr)');
assert(formatCompactINR(25000) === '₹25K', 'formatCompactINR formats Thousands (25K)');
assert(formatCompactINR(500) === '₹500', 'formatCompactINR formats < 1000 correctly');

// 2. Smart UPI / SMS Parser
console.log('\n--- 2. Testing Smart UPI & SMS Parser ---');
const hdfcSwiggySms = "Rs 489.00 debited from A/C **1234 on 22-OCT-26 to VPA Swiggy via UPI ref 4293817492.";
const parsedSwiggy = parseBankSMS(hdfcSwiggySms, 'salaried');
assert(parsedSwiggy.amount === 489, 'Extracts correct amount from HDFC Swiggy SMS');
assert(parsedSwiggy.title === 'Swiggy', 'Identifies Swiggy as merchant');
assert(parsedSwiggy.type === 'expense', 'Categorizes as expense');
assert(parsedSwiggy.category === 'Food & Dining', 'Assigns Food & Dining category');
assert(parsedSwiggy.tag === 'wants', 'Tags Swiggy as Wants');

const salarySms = "Your A/C **5678 is credited with INR 85,000.00 on 01-OCT-26 towards October Salary from ACME CORP.";
const parsedSalary = parseBankSMS(salarySms, 'salaried');
assert(parsedSalary.amount === 85000, 'Extracts salary amount correctly');
assert(parsedSalary.type === 'income', 'Identifies credit as income');

const blinkitSms = "Sent Rs. 642 to Blinkit via PhonePe UPI.";
const parsedBlinkit = parseBankSMS(blinkitSms, 'salaried');
assert(parsedBlinkit.amount === 642, 'Extracts Blinkit amount');
assert(parsedBlinkit.category === 'Groceries & Daily Needs', 'Identifies Blinkit as Groceries');
assert(parsedBlinkit.tag === 'essential', 'Tags Blinkit as Essential');

// 3. Payday Survival & Daily Burn Math
console.log('\n--- 3. Testing Payday Survival Engine ---');
function calculateSurvival(balance, pendingBills, daysToPayday, mode = 'salaried') {
  const effectiveFunds = Math.max(0, balance - pendingBills);
  const effectiveDays = Math.max(1, daysToPayday);
  const dailyLimit = Math.floor(effectiveFunds / effectiveDays);

  const thresholdRed = mode === 'salaried' ? 450 : 2500;
  const thresholdAmber = mode === 'salaried' ? 1200 : 6500;

  let status = 'safe';
  if (effectiveFunds <= 0 || dailyLimit < thresholdRed) status = 'danger';
  else if (dailyLimit < thresholdAmber) status = 'amber';

  return { effectiveFunds, dailyLimit, status };
}

const res1 = calculateSurvival(45000, 15000, 10, 'salaried');
assert(res1.effectiveFunds === 30000, 'Calculates effective free funds');
assert(res1.dailyLimit === 3000, 'Calculates safe daily spend limit');
assert(res1.status === 'safe', 'Assigns safe status when limit is generous');

const res2 = calculateSurvival(18000, 16000, 10, 'salaried');
assert(res2.effectiveFunds === 2000, 'Calculates low buffer');
assert(res2.dailyLimit === 200, 'Calculates tight daily limit (200/day)');
assert(res2.status === 'danger', 'Triggers Code Red Crunch alert (< 450/day)');

const res3 = calculateSurvival(25000, 16000, 10, 'salaried');
assert(res3.dailyLimit === 900, 'Calculates medium limit (900/day)');
assert(res3.status === 'amber', 'Triggers Amber Burn Warning (450 - 1200/day)');

// 4. Credit Card Trap APR Math
console.log('\n--- 4. Testing Credit Card Trap Engine ---');
function calcCreditCardTrap(balance, apr = 42, minDuePercent = 5) {
  const minDueAmount = Math.max(500, Math.round(balance * (minDuePercent / 100)));
  const monthlyRate = (apr / 100) / 12;
  const ratio = (balance * monthlyRate) / minDueAmount;
  let monthsMin = 64;
  if (ratio < 1) {
    monthsMin = Math.round(Math.log(1 / (1 - ratio)) / Math.log(1 + monthlyRate));
  }
  const totalInterestMin = Math.round(balance * 0.48 * (monthsMin / 12) * 0.6);
  return { minDueAmount, monthsMin, totalInterestMin };
}

const ccRes = calcCreditCardTrap(50000);
assert(ccRes.minDueAmount === 2500, '5% min due on 50,000 is 2,500');
assert(ccRes.monthsMin >= 30, `Calculates compound debt trap months: ${ccRes.monthsMin} months`);
assert(ccRes.totalInterestMin > 20000, `Calculates massive bank interest penalty: ₹${ccRes.totalInterestMin}`);

// 5. Business Invoice & Section 44ADA / GST Reserves
console.log('\n--- 5. Testing Freelancer / Business Tax Reserves ---');
function calcBusinessReserves(revenue) {
  const gstReserve = Math.round(revenue * 0.18);
  const incomeTax44ADA = Math.round(revenue * 0.10); // 50% deemed profit @ 20% slab
  return { gstReserve, incomeTax44ADA };
}

const bizRes = calcBusinessReserves(200000);
assert(bizRes.gstReserve === 36000, 'Calculates 18% GST liability reserve on 2L');
assert(bizRes.incomeTax44ADA === 20000, 'Calculates Sec 44ADA deemed profit tax reserve on 2L');

console.log(`\n========================================`);
console.log(`📊 TEST RESULTS: ${passed} Passed | ${failed} Failed`);
console.log(`========================================\n`);

if (failed > 0) {
  process.exit(1);
} else {
  console.log('🚀 ALL CORE FUNCTIONS VERIFIED SUCCESSFULLY!');
}
