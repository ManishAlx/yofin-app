$projectDir = "d:\yofin-app"
$zipPath1 = "d:\yofin-app\yofin-app-complete.zip"
$zipPath2 = "d:\yofin-app.zip"

if (Test-Path $zipPath1) { Remove-Item $zipPath1 -Force }
if (Test-Path $zipPath2) { Remove-Item $zipPath2 -Force }

$items = Get-ChildItem -Path $projectDir -Force | Where-Object {
    $_.Name -ne 'node_modules' -and
    $_.Name -ne 'dist' -and
    $_.Extension -ne '.zip'
}

Write-Host "Zipping the following items:"
foreach ($item in $items) {
    Write-Host " - $($item.Name)"
}

Compress-Archive -Path $items.FullName -DestinationPath $zipPath1 -Force
Copy-Item $zipPath1 $zipPath2 -Force

Write-Host "`nZip creation complete!"
Get-Item $zipPath1, $zipPath2 | Select-Object FullName, @{Name="Size(KB)"; Expression={[math]::Round($_.Length / 1KB, 2)}}
