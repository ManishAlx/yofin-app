import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Scissors, 
  AlertOctagon, 
  Trash2, 
  Plus, 
  ZapOff
} from 'lucide-react';
import { formatINR } from '../lib/formatters';

export function SubscriptionStopper({ 
  subscriptions, 
  onToggleActive, 
  onDeleteSubscription, 
  onAddSubscription,
  mode 
}) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [newName, setNewName] = useState('');
  const [newAmount, setNewAmount] = useState('');
  const [newCategory, setNewCategory] = useState('Streaming');

  const modeSubs = subscriptions.filter(s => s.mode === mode);
  const activeSubs = modeSubs.filter(s => s.is_active);
  const leakSubs = activeSubs.filter(s => s.leak_warning);

  const monthlyLeakSum = leakSubs.reduce((sum, s) => sum + Number(s.amount), 0);
  const annualLeakSum = monthlyLeakSum * 12;

  const handleCreate = (e) => {
    e.preventDefault();
    if (!newName || !newAmount) return;

    onAddSubscription({
      id: `sub-${Date.now()}`,
      name: newName,
      amount: parseFloat(newAmount),
      billing_cycle: 'monthly',
      next_billing_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      category: newCategory,
      is_active: true,
      last_used_date: new Date().toISOString().split('T')[0],
      mode,
      leak_warning: null
    });

    setNewName('');
    setNewAmount('');
    setShowAddForm(false);
  };

  return (
    <motion.div 
      whileHover={{ y: -2 }}
      className={`glass-card p-6 sm:p-7 my-6 transition-all duration-300 ${
        leakSubs.length > 0 ? 'border-amber-500/40' : 'border-white/[0.08]'
      }`}
    >
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3 mb-6">
        <div className="flex items-center gap-3.5">
          <div className={`w-11 h-11 rounded-xl flex items-center justify-center border ${
            leakSubs.length > 0 
              ? 'bg-amber-500/15 border-amber-500/35 text-amber-400' 
              : 'bg-emerald-500/15 border-emerald-500/35 text-emerald-400'
          }`}>
            <Scissors size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h3 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
                Money Leaks & Unused Subscription Stopper
              </h3>
              {leakSubs.length > 0 && (
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider bg-amber-500/15 text-amber-400 border border-amber-500/30">
                  {leakSubs.length} Zombie Leaks Detected
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400">
              Identifies dormant subscriptions, recurring SaaS, and autopay drains to stop financial bleed
            </p>
          </div>
        </div>

        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowAddForm(!showAddForm)}
          className="btn-fintech-secondary text-xs !py-1.5 !px-3.5 rounded-full"
        >
          <Plus size={14} className="text-cyan-400" />
          <span>{showAddForm ? 'Cancel' : 'Track Subscription'}</span>
        </motion.button>
      </div>

      {/* Annual Savings Spotlight Banner */}
      {leakSubs.length > 0 && (
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-transparent border border-amber-500/30 mb-5 flex items-center justify-between flex-wrap gap-3">
          <div>
            <div className="text-[11px] font-bold text-amber-400 uppercase tracking-wider">
              Potential Annual Recoverable Wealth
            </div>
            <div className="font-mono text-2xl sm:text-3xl font-extrabold text-white mt-0.5">
              {formatINR(annualLeakSum)} <span className="text-xs font-semibold text-slate-400 font-sans">/ year saved</span>
            </div>
            <div className="text-xs text-slate-300 mt-1">
              You are losing <strong>{formatINR(monthlyLeakSum)}/month</strong> to services you haven't touched in over 30 days!
            </div>
          </div>

          <span className="text-[10px] font-bold px-3 py-1.5 rounded-full uppercase tracking-wider bg-rose-500/15 text-rose-400 border border-rose-500/30">
            Action: Cancel or Pause
          </span>
        </div>
      )}

      {/* Add Subscription Drawer */}
      <AnimatePresence>
        {showAddForm && (
          <motion.form
            onSubmit={handleCreate}
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="p-5 rounded-2xl bg-black/45 border border-white/[0.08] mb-5"
          >
            <div className="text-sm font-bold text-white mb-3">
              Add Recurring Payment to Monitor
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-xs text-slate-300 block mb-1">
                  Subscription Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Netflix, Gym, AWS, Spotify"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="fintech-input"
                />
              </div>

              <div>
                <label className="text-xs text-slate-300 block mb-1">
                  Monthly Cost (₹)
                </label>
                <input
                  type="number"
                  step="any"
                  required
                  placeholder="e.g. 649"
                  value={newAmount}
                  onChange={(e) => setNewAmount(e.target.value)}
                  className="fintech-input"
                />
              </div>

              <div>
                <label className="text-xs text-slate-300 block mb-1">
                  Category
                </label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  className="fintech-input"
                >
                  <option value="Streaming" className="bg-[#121520]">Streaming & OTT</option>
                  <option value="Fitness" className="bg-[#121520]">Fitness & Wellness</option>
                  <option value="SaaS Tools" className="bg-[#121520]">SaaS Tools & Software</option>
                  <option value="Cloud / Infra" className="bg-[#121520]">Cloud & Web Infrastructure</option>
                  <option value="Utilities" className="bg-[#121520]">Utilities & Broadband</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-2.5 mt-4">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="btn-fintech-secondary text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn-fintech-primary text-xs"
              >
                Save Subscription
              </button>
            </div>
          </motion.form>
        )}
      </AnimatePresence>

      {/* Subscription Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {modeSubs.length === 0 ? (
          <div className="col-span-full py-8 text-center text-slate-400 text-xs">
            No subscriptions tracked yet for this mode. Click "Track Subscription" above to add one.
          </div>
        ) : (
          modeSubs.map((sub) => {
            const isLeak = Boolean(sub.leak_warning && sub.is_active);

            return (
              <motion.div
                key={sub.id}
                layout
                className={`p-4 sm:p-5 rounded-2xl border transition-all flex flex-col justify-between gap-3 ${
                  isLeak 
                    ? 'border-amber-500/40 bg-amber-500/[0.06]' 
                    : 'border-white/[0.08] bg-black/35'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-bold text-white">
                      {sub.name}
                    </span>
                    <span className={`font-mono text-base font-extrabold ${isLeak ? 'text-amber-400' : 'text-emerald-400'}`}>
                      {formatINR(sub.amount)}<span className="text-[10px] text-slate-400 font-sans">/mo</span>
                    </span>
                  </div>

                  <div className="text-xs text-slate-400 flex items-center gap-1.5 mt-0.5">
                    <span>{sub.category}</span>
                    <span>•</span>
                    <span>Renews {sub.next_billing_date}</span>
                  </div>

                  {isLeak && (
                    <div className="mt-2.5 p-2 rounded-xl bg-amber-500/10 border border-amber-500/25 text-[11px] text-amber-300 flex items-start gap-1.5 font-medium">
                      <AlertOctagon size={14} className="shrink-0 mt-0.5" />
                      <span>{sub.leak_warning}</span>
                    </div>
                  )}

                  {!sub.is_active && (
                    <div className="mt-2 text-xs text-slate-500 flex items-center gap-1.5 font-medium">
                      <ZapOff size={13} />
                      <span>Subscription Cancelled / Paused</span>
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between pt-2.5 border-t border-white/[0.06] mt-2">
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={() => onToggleActive(sub.id)}
                    className={`text-xs px-3 py-1 rounded-full font-semibold transition-all cursor-pointer ${
                      sub.is_active 
                        ? 'bg-rose-500/15 text-rose-300 border border-rose-500/30 hover:bg-rose-500/25' 
                        : 'bg-white/[0.06] text-slate-300 border border-white/[0.08] hover:text-white'
                    }`}
                  >
                    {sub.is_active ? 'Kill Subscription' : 'Reactivate'}
                  </motion.button>

                  <button
                    onClick={() => onDeleteSubscription(sub.id)}
                    className="text-slate-500 hover:text-rose-400 p-1 rounded-lg transition-all cursor-pointer"
                    title="Remove from tracking"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </motion.div>
            );
          })
        )}
      </div>
    </motion.div>
  );
}
